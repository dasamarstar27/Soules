# Season Two: The Broken Bridge

Implemented after Chapter One in `source_story.py`, `season_two.py` and `village_life.py`.

Chapter One is the Dreamscape invasion: monsters were once fewer and peaceful, but the Dreamscape boss sends hostile monsters to overrun the world. Unlock the main regions and defeat The Dreaming God to finish it. The Creator is not required.

Season Two takes place five months after that victory. Complete 20 side quests during the rebuilding interlude, then start it from the story journal or mentor conversation. There is no real-time wait. The four elemental villages then report unstable Source channels. Their keepers provide evidence that someone deliberately tampered with the Core Stabiliser. A former keeper, currently named Vael, tried to force it into opening a bridge to the Creator's Realm. The attempt broke the stabiliser and unbalanced Source energy.

Playable progression:

1. Find the four existing hidden elemental villages. Discovery remains rare; known villages can be revisited through Structures or the village directory.
2. Ask each elemental keeper about the Source through its expanded village menu. The journal records each unique testimony.
3. With all four accounts, choose the investigation from Story & Lore / the story journal. Travel to the Source Temple in Riftlands and confront Vael at the Broken Bridge.
4. Defeat Vael. This encounter does not count as a regional guardian or unlock unrelated regions.
5. Use the four clans’ harmonic knowledge to repair the stabiliser. The four cores remain in their villages and are not carried to or consumed at the temple. Source balance is restored and Season Two completes.

The Creator is not a required boss in either chapter. The ending leaves open what noticed the unfinished bridge from the far side. Season Three is now playable through the Adventures hub after this ending; see SEASON_THREE_GUIDE.md.

Villages retain their core encounters, element-themed shops, training, exclusive libraries and side quests. Local services vary in availability and quality. Food stock, farm regrowth, notes, tags and reputation persist with the character. Postgame anomalies offer optional Source fragments while wandering.
