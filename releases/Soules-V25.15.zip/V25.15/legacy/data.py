# =========================
# datapack for game 
# =========================

# ================= REGIONS =================
REGIONS = [
    "Whispering Woods",
    "Ashen Wastes",
    "Crimson Depths",
    "Frostbound Tundra",
    "Crystal Spire",
    "Sunken Coast",
    "Ironpeak Mountains",
    "Blight Swamp",
    "Shattered Wastes",
    "Shadow Vale",
    "Infernal Depths",
    "Celestial Expanse",
    "Riftlands",
    "Abyss of Souls",
    "The Dreamscape",
]

SECRET_REGION = "Creator's Realm"

# =========================================================
# NORMAL MONSTERS
# =========================================================

NORMAL_MONSTERS = {
    "Whispering Woods": [
        {"name": "Thorn Wolf", "hp": 30, "atk": 10, "def": 2, "effect": "poison"},
        {"name": "Root Stalker", "hp": 35, "atk": 11, "def": 3, "effect": "root"}
    ],

    "Ashen Wastes": [
        {"name": "Ash Lizard", "hp": 40, "atk": 13, "def": 1, "effect": "burn"},
        {"name": "Dust Scavenger", "hp": 38, "atk": 16, "def": 2, "effect": "blind"}
    ],

    "Crimson Depths": [
        {"name": "Forge Warden", "hp": 50, "atk": 14, "def": 3, "effect": "magma"},
        {"name": "Molten Automaton", "hp": 55, "atk": 16, "def": 4, "effect": "burn"}
    ],

    "Frostbound Tundra": [
        {"name": "Ice Stag", "hp": 45, "atk": 9, "def": 13, "effect": "freeze"},
        {"name": "Snow Ripper", "hp": 42, "atk": 8, "def": 20, "effect": "freeze"}
    ],

    "Crystal Spire": [
        {"name": "Shard Pixie", "hp": 52, "atk": 15, "def": 4, "effect": "freeze"},
        {"name": "Prism Serpent", "hp": 58, "atk": 17, "def": 5, "effect": "shock"}
    ],

    "Sunken Coast": [
        {"name": "Tide Eel", "hp": 48, "atk": 20, "def": 12, "effect": "shock"},
        {"name": "Barnacle Beast", "hp": 52, "atk": 10, "def": 4, "effect": "bleed"}
    ],

    "Ironpeak Mountains": [
        {"name": "Stone Ram", "hp": 55, "atk": 10, "def": 5, "effect": "stun"},
        {"name": "Cliff Prowler", "hp": 50, "atk": 9, "def": 4, "effect": "bleed"}
    ],

    "Blight Swamp": [
        {"name": "Rot Leech", "hp": 45, "atk": 8, "def": 3, "effect": "poison"},
        {"name": "Mire Crawler", "hp": 50, "atk": 9, "def": 4, "effect": "slow"}
    ],

    "Shadow Vale": [
        {"name": "Shade Wolf", "hp": 55, "atk":  21, "def": 4, "effect": "void"},
        {"name": "Night Stalker", "hp": 60, "atk": 21, "def": 5, "effect": "blind"}
    ],

    "Riftlands": [
        {"name": "Rift Hound", "hp": 65, "atk": 34, "def": 5, "effect": "shock"},
        {"name": "Anomaly Spawn", "hp": 70, "atk": 25, "def": 5, "effect": "void"}
    ],

    "Infernal Depths": [
        {"name": "Lava Serpent", "hp": 75, "atk": 34, "def": 6, "effect": "burn"},
        {"name": "Ash Demon", "hp": 80, "atk": 25, "def": 6, "effect": "burn"}
    ],

    "Celestial Expanse": [
        {"name": "Star Wisp", "hp": 85, "atk": 30, "def": 24, "effect": "light"},
        {"name": "Astral Hawk", "hp": 90, "atk": 39, "def": 30, "effect": "shock"}
    ],

    "Shattered Wastes": [
        {"name": "Shard Crawler",    "hp": 80,  "atk": 22, "def": 8,  "effect": "bleed"},
        {"name": "Fracture Golem",   "hp": 90,  "atk": 24, "def": 10, "effect": "stun"},
    ],
    "The Dreamscape": [
        {"name": "Dream Phantom",    "hp": 75,  "atk": 18, "def": 6,  "effect": "sleep"},
        {"name": "Nightmare Wraith", "hp": 85,  "atk": 20, "def": 7,  "effect": "fear"},
    ],
    "Abyss of Souls": [
        {"name": "Soul Drifter", "hp": 95, "atk": 37, "def": 24, "effect": "void"},
        {"name": "Void Wraith", "hp": 100, "atk": 48, "def": 43, "effect": "void"}
    ],
    "Creator's Realm": []
}

# =========================================================
# EVOLVED MONSTERS
# =========================================================

EVOLVED_MONSTERS = {
    "Whispering Woods": [
        {"name": "Corrupted Thorn Wolf", "hp": 70, "atk": 12, "def": 5, "effects": ["poison", "bleed"]},
        {"name": "Ancient Root Horror", "hp": 80, "atk": 14, "def": 6, "effects": ["root", "poison"]}
    ],

    "Ashen Wastes": [
        {"name": "Molten Ash Lizard", "hp": 90, "atk": 15, "def": 6, "effects": ["burn"]},
        {"name": "Cinder Wraith", "hp": 95, "atk": 16, "def": 6, "effects": ["burn", "shock"]}
    ],

    "Crimson Depths": [
        {"name": "Infernal Golem", "hp": 105, "atk": 18, "def": 7, "effects": ["magma", "burn"]},
        {"name": "Forge Wraith", "hp": 110, "atk": 19, "def": 8, "effects": ["burn", "stun"]}
    ],

    "Frostbound Tundra": [
        {"name": "Glacier Beast", "hp": 100, "atk": 17, "def": 7, "effects": ["freeze"]},
        {"name": "Permafrost Titan", "hp": 110, "atk": 18, "def": 8, "effects": ["freeze", "stun"]}
    ],

    "Crystal Spire": [
        {"name": "Crystal Guardian", "hp": 115, "atk": 20, "def": 8, "effects": ["freeze", "reflect"]},
        {"name": "Spire Warden", "hp": 120, "atk": 21, "def": 9, "effects": ["shock", "shield"]}
    ],

    "Sunken Coast": [
        {"name": "Deepsea Horror", "hp": 115, "atk": 18, "def": 7, "effects": ["shock", "bleed"]},
        {"name": "Kraken Spawn", "hp": 120, "atk": 19, "def": 8, "effects": ["shock", "void"]}
    ],

    "Ironpeak Mountains": [
        {"name": "Granite Colossus", "hp": 125, "atk": 20, "def": 10, "effects": ["stun"]},
        {"name": "Ironfang Beast", "hp": 130, "atk": 21, "def": 10, "effects": ["bleed"]}
    ],

    "Blight Swamp": [
        {"name": "Rotting Abomination", "hp": 120, "atk": 19, "def": 9, "effects": ["poison"]},
        {"name": "Swamp Horror", "hp": 125, "atk": 20, "def": 9, "effects": ["poison", "slow"]}
    ],

    "Shadow Vale": [
        {"name": "Void Stalker", "hp": 130, "atk": 22, "def": 10, "effects": ["void", "blind"]},
        {"name": "Nightmare Shade", "hp": 135, "atk": 23, "def": 11, "effects": ["void"]}
    ],

    "Riftlands": [
        {"name": "Dimensional Horror", "hp": 140, "atk": 24, "def": 11, "effects": ["shock", "void"]},
        {"name": "Rift Breaker", "hp": 145, "atk": 25, "def": 12, "effects": ["shock"]}
    ],

    "Infernal Depths": [
        {"name": "Infernal Demon", "hp": 150, "atk": 26, "def": 13, "effects": ["burn"]},
        {"name": "Hellfire Behemoth", "hp": 160, "atk": 28, "def": 14, "effects": ["burn", "magma"]}
    ],

    "Celestial Expanse": [
        {"name": "Star Angel", "hp": 165, "atk": 28, "def": 14, "effects": ["light", "heal"]},
        {"name": "Cosmic Seraph", "hp": 175, "atk": 30, "def": 15, "effects": ["light", "shock"]}
    ],

    "Abyss of Souls": [
        {"name": "Soul Devourer", "hp": 180, "atk": 32, "def": 16, "effects": ["void", "life_drain"]},
        {"name": "Eternal Abyss King", "hp": 200, "atk": 35, "def": 18, "effects": ["void", "curse"]}
    ],
    "Shattered Wastes": [
        {"name": "Shard Crawler",    "hp": 110, "atk": 22, "def": 8,  "effects": ["bleed", "void"]},
        {"name": "Fracture Golem",   "hp": 120, "atk": 24, "def": 10, "effects": ["stun", "bleed"]},
    ],
    "The Dreamscape": [
        {"name": "Lucid Devourer",   "hp": 135, "atk": 26, "def": 11, "effects": ["sleep", "fear"]},
        {"name": "Dreamweaver Lich", "hp": 145, "atk": 28, "def": 12, "effects": ["fear", "void"]},
    ],
    "Creator's Realm": []
}

# =========================================================
# MINI BOSSES
# =========================================================

MINI_BOSSES = {
    "Whispering Woods": [
        {"name": "Forest Executioner", "hp": 250, "atk": 36, "def": 20},
        {"name": "Ancient Treant", "hp": 270, "atk": 42, "def": 22}
    ],

    "Ashen Wastes": [
        {"name": "Ash Colossus", "hp": 280, "atk": 70, "def": 22},
        {"name": "Cinder Titan", "hp": 300, "atk": 54, "def": 24}
    ],

    "Crimson Depths": [
        {"name": "Forge Colossus", "hp": 320, "atk": 80, "def": 26},
        {"name": "Molten Brute", "hp": 340, "atk": 82, "def": 28}
    ],

    "Frostbound Tundra": [
        {"name": "Glacier Warden", "hp": 320, "atk": 98, "def": 25},
        {"name": "Frozen Juggernaut", "hp": 340, "atk": 86, "def": 27}
    ],

    "Crystal Spire": [
        {"name": "Prismatic Colossus", "hp": 360, "atk": 101, "def": 28},
        {"name": "Spire Titan", "hp": 380, "atk": 119, "def": 30}
    ],

    "Sunken Coast": [
        {"name": "Deepsea Leviathan", "hp": 360, "atk": 142, "def": 28},
        {"name": "Tidebreaker Horror", "hp": 380, "atk": 144, "def": 30}
    ],

    "Ironpeak Mountains": [
        {"name": "Mountain Crusher", "hp": 400, "atk": 146, "def": 32},
        {"name": "Ironhide Behemoth", "hp": 420, "atk": 148, "def": 34}
    ],

    "Blight Swamp": [
        {"name": "Rot King", "hp": 440, "atk": 150, "def": 35},
        {"name": "Plague Bringer", "hp": 460, "atk": 152, "def": 37}
    ],

    "Shadow Vale": [
        {"name": "Void Assassin", "hp": 500, "atk": 155, "def": 40},
        {"name": "Nightmare Lord", "hp": 520, "atk": 158, "def": 42}
    ],

    "Riftlands": [
        {"name": "Rift Guardian", "hp": 550, "atk": 160, "def": 45},
        {"name": "Dimensional Tyrant", "hp": 580, "atk": 165, "def": 47}
    ],

    "Infernal Depths": [
        {"name": "Hellforge Titan", "hp": 620, "atk": 168, "def": 50},
        {"name": "Infernal Overlord", "hp": 650, "atk": 170, "def": 52}
    ],

    "Celestial Expanse": [
        {"name": "Astral Archon", "hp": 700, "atk": 175, "def": 55},
        {"name": "Starborn Seraph", "hp": 730, "atk": 178, "def": 57}
    ],

    "Shattered Wastes": [
        {"name": "Prism Warlord",   "hp": 480, "atk": 155, "def": 38},
        {"name": "Fracture Titan",  "hp": 510, "atk": 160, "def": 40}
    ],
    "The Dreamscape": [
        {"name": "Lucid Colossus",  "hp": 820, "atk": 187, "def": 62},
        {"name": "Dream Tyrant",    "hp": 860, "atk": 192, "def": 66}
    ],
    "Abyss of Souls": [
        {"name": "Soul Harvester", "hp": 800, "atk": 185, "def": 60},
        {"name": "Abyssal Reaper", "hp": 850, "atk": 190, "def": 65}
    ],

    "Creator's Realm": [
        {"name": "Manifested Thought", "hp": 900, "atk": 195, "def": 70},
        {"name": "Worldforged Sentinel", "hp": 940, "atk": 198, "def": 72}
    ]
}

# =========================================================
# REGION BOSSES
# =========================================================

REGION_BOSSES = {
    "Whispering Woods": {"name": "The Verdant King", "hp": 900, "atk": 160, "def": 40, "phases": 3},
    "Ashen Wastes": {"name": "Ember Tyrant", "hp": 1000, "atk": 170, "def": 45, "phases": 3},
    "Crimson Depths": {"name": "Crimson Furnace", "hp": 1100, "atk": 175, "def": 50, "phases": 3},
    "Frostbound Tundra": {"name": "Frost Monarch", "hp": 1100, "atk": 175, "def": 50, "phases": 3},
    "Crystal Spire": {"name": "Crystal Sovereign", "hp": 1250, "atk":182, "def": 55, "phases": 3},
    "Sunken Coast": {"name": "Kraken Sovereign", "hp": 1200, "atk": 180, "def": 55, "phases": 3},
    "Ironpeak Mountains": {"name": "Titan of Peaks", "hp": 1300, "atk": 185, "def": 60, "phases": 3},
    "Blight Swamp": {"name": "The Rotfather", "hp": 1400, "atk": 190, "def": 65, "phases": 3},
    "Shadow Vale": {"name": "Void Emperor", "hp": 1500, "atk": 200, "def": 70, "phases": 3},
    "Riftlands": {"name": "The Rift Sovereign", "hp": 1700, "atk": 210, "def": 75, "phases": 3},
    "Infernal Depths": {"name": "Lord of Infernos", "hp": 1900, "atk": 220, "def": 80, "phases": 3},
    "Celestial Expanse": {"name": "The Celestial Arbiter", "hp": 2200, "atk": 230, "def": 90, "phases": 3},
    "Shattered Wastes": {"name": "The Shard Overlord",   "hp": 1600, "atk": 205, "def": 72, "phases": 3},
    "The Dreamscape":   {"name": "The Dreaming God",     "hp": 2600, "atk": 240, "def": 95, "phases": 4},
    "Abyss of Souls": {"name": "The Soul Devourer Supreme", "hp": 3000, "atk": 250, "def": 100, "phases": 4},
    "Creator's Realm": {"name": "The Creator", "hp": 4200, "atk": 175, "def": 220, "phases": 5}
}
BOSS_DROPS = {
    "Whispering Woods":   ["Verdant Heart", "Nature Core", "Forest Crown"],
    "Ashen Wastes":       ["Ember Core", "Cinder Shard", "Ash Heart"],
    "Crimson Depths":      ["Molten Core", "Forge Ember", "Inferno Shard"],
    "Frostbound Tundra":  ["Frozen Heart", "Glacier Core", "Frost Crown"],
    "Crystal Spire":      ["Prismatic Crystal", "Spire Core", "Crystal Heart"],
    "Sunken Coast":       ["Leviathan Eye", "Ocean Core", "Tide Shard"],
    "Ironpeak Mountains": ["Titan Stone", "Iron Core", "Peak Shard"],
    "Blight Swamp":       ["Blight Core", "Rot Shard", "Plague Heart"],
    "Shadow Vale":        ["Void Essence", "Shadow Core", "Dark Shard"],
    "Riftlands":          ["Rift Crystal", "Anomaly Core", "Tear Shard"],
    "Infernal Depths":    ["Infernal Heart", "Hellfire Core", "Demon Shard"],
    "Celestial Expanse":  ["Celestial Fragment", "Star Core", "Astral Heart"],
    "Shattered Wastes":   ["Shard Core", "Fracture Essence", "Prism Heart"],
    "The Dreamscape":     ["Dream Fragment", "Lucid Core", "Nightmare Shard"],
    "Abyss of Souls":     ["Soul Core", "Abyss Shard", "Soul Crown"],
    "Creator's Realm":    ["Creator Shard", "Omnipotent Core", "World Seed"],
}
# =========================
# COMPANIONS (2 PER REGION)
# =========================

COMPANIONS = {
    "Whispering Woods": [
        {"name": "Forest Sprite", "element": "nature", "can_battle": False},
        {"name": "Gloom Stag", "element": "shadow", "can_battle": True},
    ],
    "Ashen Wastes": [
        {"name": "Ember Fox", "element": "fire", "can_battle": True},
        {"name": "Cinder Wisp", "element": "fire", "can_battle": False},
    ],
    "Frostbound Tundra": [
        {"name": "Glacier Hare", "element": "ice", "can_battle": False},
        {"name": "Frost Drake", "element": "ice", "can_battle": True},
    ],
    "Sunken Coast": [
        {"name": "Coral Siren", "element": "water", "can_battle": False},
        {"name": "Tide Guardian", "element": "water", "can_battle": True},
    ],
    "Ironpeak Mountains": [
        {"name": "Stone Golem", "element": "earth", "can_battle": True},
        {"name": "Quartz Ram", "element": "earth", "can_battle": False},
    ],
    "Blight Swamp": [
        {"name": "Mire Crawler", "element": "poison", "can_battle": True},
        {"name": "Bog Witch", "element": "poison", "can_battle": False},
    ],
    "Shadow Vale": [
        {"name": "Nightshade Lynx", "element": "shadow", "can_battle": True},
        {"name": "Veil Phantom", "element": "shadow", "can_battle": False},
    ],
    "Riftlands": [
        {"name": "Aether Hound", "element": "void", "can_battle": True},
        {"name": "Rift Sprite", "element": "void", "can_battle": False},
    ],
    "Infernal Depths": [
        {"name": "Flame Imp", "element": "fire", "can_battle": True},
        {"name": "Ash Sentinel", "element": "fire", "can_battle": False},
    ],
    "Celestial Expanse": [
        {"name": "Starry Owl", "element": "light", "can_battle": True},
        {"name": "Lunar Fox", "element": "light", "can_battle": False},
    ],
    "Shattered Wastes": [
        {"name": "Prism Hawk",    "element": "crystal", "can_battle": True},
        {"name": "Shard Sprite",  "element": "void",    "can_battle": False},
    ],
    "The Dreamscape": [
        {"name": "Dream Fox",     "element": "arcane",  "can_battle": True},
        {"name": "Nightmare Cat", "element": "shadow",  "can_battle": False},
    ],
    "Abyss of Souls": [
        {"name": "Soul Warden", "element": "soul", "can_battle": True},
        {"name": "Abyssal Nymph", "element": "soul", "can_battle": False},
    ],
}

# =========================
# RUNES ALOT
# =========================

RUNES = [
    {"name": "Flame Rune", "effect": "burn", "element": "fire"},
    {"name": "Water Rune", "effect": "soak", "element": "water"},
    {"name": "Earth Rune", "effect": "defense_up", "element": "earth"},
    {"name": "Wind Rune", "effect": "speed_up", "element": "wind"},
    {"name": "Lightning Rune", "effect": "shock", "element": "lightning"},
    {"name": "Ice Rune", "effect": "freeze", "element": "ice"},
    {"name": "Nature Rune", "effect": "regen", "element": "nature"},
    {"name": "Poison Rune", "effect": "poison", "element": "poison"},
    {"name": "Shadow Rune", "effect": "blind", "element": "shadow"},
    {"name": "Light Rune", "effect": "heal_tick", "element": "light"},

    {"name": "Metal Rune", "effect": "armor_break", "element": "metal"},
    {"name": "Crystal Rune", "effect": "crit_up", "element": "crystal"},
    {"name": "Blood Rune", "effect": "life_drain", "element": "blood"},
    {"name": "Spirit Rune", "effect": "mana_regen", "element": "spirit"},
    {"name": "Storm Rune", "effect": "chain_shock", "element": "storm"},
    {"name": "Magma Rune", "effect": "magma", "element": "magma"},
    {"name": "Frostfire Rune", "effect": "burn_freeze", "element": "frostfire"},
    {"name": "Venom Rune", "effect": "deadly_poison", "element": "venom"},
    {"name": "Root Rune", "effect": "root", "element": "nature"},
    {"name": "Stone Rune", "effect": "stun", "element": "earth"},

    {"name": "Void Rune", "effect": "void_burn", "element": "void"},
    {"name": "Abyss Rune", "effect": "curse", "element": "abyss"},
    {"name": "Celestial Rune", "effect": "divine_luck", "element": "celestial"},
    {"name": "Astral Rune", "effect": "starfall", "element": "astral"},
    {"name": "Solar Rune", "effect": "sun_blast", "element": "solar"},
    {"name": "Lunar Rune", "effect": "moon_guard", "element": "lunar"},
    {"name": "Time Rune", "effect": "slow_time", "element": "time"},
    {"name": "Space Rune", "effect": "warp", "element": "space"},
    {"name": "Gravity Rune", "effect": "crush", "element": "gravity"},
    {"name": "Chaos Rune", "effect": "random_effect", "element": "chaos"},

    {"name": "Order Rune", "effect": "stability", "element": "order"},
    {"name": "Dream Rune", "effect": "sleep", "element": "dream"},
    {"name": "Nightmare Rune", "effect": "fear", "element": "nightmare"},
    {"name": "Soul Rune", "effect": "soul_drain", "element": "soul"},
    {"name": "Life Rune", "effect": "greater_regen", "element": "life"},
    {"name": "Death Rune", "effect": "execute", "element": "death"},
    {"name": "Echo Rune", "effect": "double_cast", "element": "echo"},
    {"name": "Mirror Rune", "effect": "reflect", "element": "mirror"},
    {"name": "Dragon Rune", "effect": "dragon_fury", "element": "dragon"},
    {"name": "Phoenix Rune", "effect": "rebirth", "element": "phoenix"},

    {"name": "Titan Rune", "effect": "giant_strength", "element": "titan"},
    {"name": "Demon Rune", "effect": "hellfire", "element": "demon"},
    {"name": "Angel Rune", "effect": "holy_barrier", "element": "angel"},
    {"name": "Ocean Rune", "effect": "tidal_wave", "element": "water"},
    {"name": "Mountain Rune", "effect": "fortress", "element": "earth"},
    {"name": "Forest Rune", "effect": "nature_blessing", "element": "forest"},
    {"name": "Rift Rune", "effect": "dimension_break", "element": "rift"},
    {"name": "Cosmic Rune", "effect": "reality_bend", "element": "cosmic"},
    {"name": "Eternity Rune", "effect": "time_lock", "element": "eternity"},
    {"name": "Arcane Rune", "effect": "arcane_burst", "element": "arcane"},
    {"name": "Plasma Rune", "effect": "plasma_surge", "element": "plasma"},
    {"name": "Sonic Rune", "effect": "sonic_shock", "element": "sonic"},
    {"name": "Ember Rune", "effect": "ember_blade", "element": "ember"},
    {"name": "Glacial Rune", "effect": "glacial_chill", "element": "glacial"},
    {"name": "Steel Rune", "effect": "steel_guard", "element": "steel"},
    {"name": "Radiant Rune", "effect": "radiant_glow", "element": "radiant"},
    {"name": "Ethereal Rune", "effect": "ethereal_wisp", "element": "ethereal"},
    {"name": "Necrotic Rune", "effect": "necrotic_decay", "element": "necrotic"},
    {"name": "Primal Rune", "effect": "primal_roar", "element": "primal"},
    {"name": "Vortex Rune", "effect": "vortex_pull", "element": "vortex"},
    {"name": "Quartz Rune", "effect": "quartz_barrier", "element": "quartz"},
    {"name": "Arcane Flame Rune", "effect": "arcane_burn", "element": "arcane"},
    {"name": "Plasma Storm Rune", "effect": "plasma_chain", "element": "plasma"},
    {"name": "Sonic Echo Rune", "effect": "sonic_echo", "element": "sonic"},
    {"name": "Ember Crystal Rune", "effect": "ember_crystal", "element": "ember"},
    {"name": "Glacial Tide Rune", "effect": "glacial_tide", "element": "glacial"},
    {"name": "Steel Root Rune", "effect": "steel_root", "element": "steel"},
    {"name": "Radiant Soul Rune", "effect": "radiant_aura", "element": "radiant"},
    {"name": "Ethereal Shadow Rune", "effect": "phase_shift", "element": "ethereal"},
    {"name": "Necrotic Blood Rune", "effect": "blood_decay", "element": "necrotic"},
    {"name": "Primal Earth Rune", "effect": "primal_force", "element": "primal"},
    {"name": "Vortex Storm Rune", "effect": "vortex_storm", "element": "vortex"},
    {"name": "Quartz Light Rune", "effect": "quartz_shine", "element": "quartz"},
    {"name": "Spectral Rune", "effect": "spectral_lash", "element": "spectral"},
    {"name": "Inferno Rune", "effect": "inferno_wave", "element": "inferno"},
    {"name": "Frost Rune", "effect": "frost_nova", "element": "frost"},
    {"name": "Thunder Rune", "effect": "thunder_clap", "element": "thunder"},
    {"name": "Tide Rune", "effect": "tide_blast", "element": "tide"},
    {"name": "Iron Rune", "effect": "iron_skin", "element": "iron"},
    {"name": "Aurora Rune", "effect": "aurora_surge", "element": "aurora"},
    {"name": "Lunar Flame Rune", "effect": "lunar_flame", "element": "lunar"},
    {"name": "Shadowfire Rune", "effect": "shadow_flame", "element": "shadow"},
    {"name": "Prism Rune", "effect": "prism_shard", "element": "prism"},
    {"name": "Magnetic Rune", "effect": "magnetic_pull", "element": "magnetic"},
    {"name": "Tempest Rune", "effect": "tempest_charge", "element": "tempest"},
    {"name": "Voidfire Rune", "effect": "void_fire", "element": "void"},
    {"name": "Eternal Rune", "effect": "eternal_light", "element": "eternal"},
    {"name": "Fate Rune", "effect": "fate_seal", "element": "fate"},
    {"name": "Harmony Rune", "effect": "harmony_wave", "element": "harmony"},
    {"name": "Ruin Rune", "effect": "ruin_blast", "element": "ruin"},
    {"name": "Glimmer Rune", "effect": "glimmer_shield", "element": "glimmer"},
    {"name": "Emberwing Rune", "effect": "ember_wing", "element": "ember"},
    {"name": "Seismic Rune", "effect": "seismic_tremor", "element": "seismic"},
    {"name": "Stormheart Rune", "effect": "stormheart", "element": "storm"},
    {"name": "Soulflare Rune", "effect": "soulflare", "element": "soul"},
    {"name": "Frostbrand Rune", "effect": "frostbrand", "element": "frost"},
    {"name": "Radiant Dawn Rune", "effect": "radiant_dawn", "element": "radiant"},
    {"name": "Silence Rune", "effect": "silence_field", "element": "silence"},
    {"name": "Enhancer Rune", "effect": "enhance_fusion", "element": "enhancer"},
    {"name": "Berserk Rune",     "effect": "berserk",         "element": "rage"},
    {"name": "Sacrifice Rune",   "effect": "sacrifice",       "element": "blood"},
    {"name": "Shatter Rune",     "effect": "shatter",         "element": "break"},
    {"name": "Overload Rune",    "effect": "overload",        "element": "arcane"},
    {"name": "Thorns Rune",      "effect": "thorns",          "element": "earth"},
    {"name": "Banish Rune",      "effect": "banish",          "element": "void"},
    {"name": "Thunder God Rune", "effect": "lightning_storm", "element": "storm"},
    {"name": "Blood Moon Rune",  "effect": "blood_moon",      "element": "blood"},
    {"name": "Ancient Rune",     "effect": "ancient_power",   "element": "ancient"},
    {"name": "Wraith Rune",      "effect": "wraith_form",     "element": "shadow"},


    {"name": "Barrier Rune",     "effect": "barrier",         "element": "barrier"},
    {"name": "Momentum Rune",    "effect": "momentum",        "element": "wind"},
    {"name": "Shard Rune",       "effect": "shard_burst",     "element": "crystal"},
    {"name": "Dream Rune",       "effect": "sleep",           "element": "dream"},
    {"name": "Quake Rune",       "effect": "stun",            "element": "earth"},
    {"name": "Lifebind Rune",    "effect": "greater_regen",   "element": "life"},
    {"name": "Nullify Rune",     "effect": "armor_break",     "element": "void"},
    {"name": "Surge Rune",       "effect": "crit_up",         "element": "arcane"},

    {"name": "Hex Rune",         "effect": "armor_break",     "element": "hex"},
    {"name": "Blaze Rune",       "effect": "burn",            "element": "fire"},
    {"name": "Glacial Ward Rune","effect": "defense_up",      "element": "ice"},
    {"name": "Crimson Rune",     "effect": "life_drain",      "element": "blood"},
    {"name": "Tempest Rune II",  "effect": "shock",           "element": "storm"},
    {"name": "Wraith Ward Rune", "effect": "holy_barrier",    "element": "shadow"},
    {"name": "Starfall Rune",    "effect": "starfall",        "element": "celestial"},
    {"name": "Leech Rune",       "effect": "life_drain",      "element": "blood"},
    {"name": "Dragon Fury Rune", "effect": "dragon_fury",     "element": "dragon"},
    {"name": "Resonance Rune",   "effect": "crit_up",         "element": "arcane"},
    {"name": "Oblivion Rune",    "effect": "execute",         "element": "death"},
    {"name": "Titan's Grip Rune","effect": "giant_strength",  "element": "titan"},


    {"name": "Dreamfire Rune",   "effect": "burn",         "element": "dream"},
    {"name": "Reaper's Mark Rune","effect": "execute",     "element": "death"},
    {"name": "Starfall II Rune", "effect": "starfall",     "element": "celestial"},
    {"name": "Iron Skin Rune",   "effect": "defense_up",   "element": "earth"},
]


# =========================
# STAFFS (50+ COMBAT TOOLS)
# =========================

STAFFS = [
    {"name": "Staff of Flame", "element": "fire", "power": 8},
    {"name": "Staff of Water", "element": "water", "power": 8},
    {"name": "Staff of Earth", "element": "earth", "power": 8},
    {"name": "Staff of Wind", "element": "wind", "power": 8},
    {"name": "Staff of Lightning", "element": "shock", "power": 9},
    {"name": "Staff of Frost", "element": "ice", "power": 9},
    {"name": "Staff of Nature", "element": "nature", "power": 9},
    {"name": "Staff of Poison", "element": "poison", "power": 9},

    {"name": "Staff of Shadows", "element": "shadow", "power": 10},
    {"name": "Staff of Light", "element": "light", "power": 10},
    {"name": "Metal Staff", "element": "metal", "power": 11},
    {"name": "Crystal Staff", "element": "crystal", "power": 11},
    {"name": "Blood Staff", "element": "blood", "power": 12},
    {"name": "Spirit Staff", "element": "spirit", "power": 12},
    {"name": "Storm Staff", "element": "storm", "power": 13},
    {"name": "Magma Staff", "element": "magma", "power": 13},

    {"name": "Frostfire Staff", "element": "hybrid", "power": 14},
    {"name": "Venom Staff", "element": "venom", "power": 14},
    {"name": "Root Staff", "element": "nature", "power": 14},
    {"name": "Stone Staff", "element": "earth", "power": 15},
    {"name": "Void Staff", "element": "void", "power": 15},
    {"name": "Abyssal Staff", "element": "abyss", "power": 16},
    # ── Content wave 3 staffs ────────────────────────────────────────
    {"name": "Dreamweaver Staff",  "element": "dream",    "power": 18},
    {"name": "Titan's Crook",      "element": "titan",    "power": 20},
    {"name": "Oblivion Rod",       "element": "death",    "power": 22},
    {"name": "Starlight Sceptre",  "element": "celestial","power": 24},
    {"name": "Dragon's Maw Staff", "element": "dragon",   "power": 26},
    {"name": "Celestial Staff", "element": "celestial", "power": 16},
    {"name": "Astral Staff", "element": "astral", "power": 17},
    {"name": "Solar Staff", "element": "solar", "power": 17},
    {"name": "Lunar Staff", "element": "lunar", "power": 17},

    {"name": "Time Staff", "element": "time", "power": 18},
    {"name": "Space Staff", "element": "space", "power": 18},
    {"name": "Gravity Staff", "element": "gravity", "power": 19},
    {"name": "Chaos Staff", "element": "chaos", "power": 20},
    {"name": "Order Staff", "element": "order", "power": 20},
    {"name": "Dream Staff", "element": "dream", "power": 20},
    {"name": "Nightmare Staff", "element": "nightmare", "power": 21},
    {"name": "Soul Staff", "element": "soul", "power": 21},

    {"name": "Life Staff", "element": "life", "power": 22},
    {"name": "Death Staff", "element": "death", "power": 22},
    {"name": "Echo Staff", "element": "echo", "power": 23},
    {"name": "Mirror Staff", "element": "mirror", "power": 23},
    {"name": "Dragon Staff", "element": "dragon", "power": 24},
    {"name": "Phoenix Staff", "element": "phoenix", "power": 24},

    {"name": "Titan Staff", "element": "titan", "power": 25},
    {"name": "Demon Staff", "element": "demon", "power": 25},
    {"name": "Angel Staff", "element": "angel", "power": 25},
    {"name": "Ocean Staff", "element": "ocean", "power": 26},
    {"name": "Mountain Staff", "element": "mountain", "power": 26},
    {"name": "Forest Staff", "element": "forest", "power": 27},
    {"name": "Rift Staff", "element": "rift", "power": 28},
    {"name": "Cosmic Staff", "element": "cosmic", "power": 30},

    {"name": "Staff of Eternity",   "element": "eternity", "power": 35},

    # ── New staffs ─────────────────────────────────────────────────────────────
    {"name": "Prism Staff",         "element": "prism",    "power": 19},
    {"name": "Shard Staff",         "element": "crystal",  "power": 21},
    {"name": "Omega Staff",         "element": "creation", "power": 32},
    {"name": "Dreambreaker Staff",  "element": "dream",    "power": 24},
    {"name": "Fracture Staff",      "element": "void",     "power": 22},
]
# =========================

# WEAPONS

# =========================

WEAPONS = [
    {"name": "Rust-Eaten Blade",         "tier": "basic",     "atk": 5,  "cores": {}},
    {"name": "Ashen Longsword",          "tier": "basic",     "atk": 7,  "cores": {}},
    {"name": "Obsidian Dagger",          "tier": "basic",     "atk": 6,  "cores": {}},
    {"name": "Bone Cleaver",             "tier": "basic",     "atk": 8,  "cores": {}},
    {"name": "Iron Shortsword",          "tier": "basic",     "atk": 9,  "cores": {}},
    {"name": "Cracked Hatchet",          "tier": "basic",     "atk": 7,  "cores": {}},
    {"name": "Thorn Whip",               "tier": "basic",     "atk": 6,  "cores": {}},

    {"name": "Gravewarden Axe",          "tier": "mid",       "atk": 12, "cores": {}},
    {"name": "Shadow Reaver",            "tier": "mid",       "atk": 14, "cores": {}},
    {"name": "Shadowthorn Rapier",       "tier": "mid",       "atk": 16, "cores": {}},
    {"name": "Ember-Forged Cleaver",     "tier": "mid",       "atk": 18, "cores": {}},
    {"name": "Bonebreaker Mace",         "tier": "mid",       "atk": 15, "cores": {}},
    {"name": "Venomfang Blade",          "tier": "mid",       "atk": 17, "cores": {}},

    {"name": "Soulreaver Greatsword",    "tier": "high",      "atk": 25, "cores": {}},
    {"name": "Voidbreaker Edge",         "tier": "high",      "atk": 32, "cores": {}},
    {"name": "Frost-Touched Spear",      "tier": "high",      "atk": 26, "cores": {}},
    {"name": "Stormweave Blade",         "tier": "high",      "atk": 28, "cores": {}},
    {"name": "Voidthorn Dagger",         "tier": "high",      "atk": 30, "cores": {}},
    {"name": "Soulpiercer Lance",        "tier": "high",      "atk": 34, "cores": {}},
    {"name": "Infernal Waraxe",          "tier": "high",      "atk": 36, "cores": {}},

    {"name": "Eclipse Executioner",      "tier": "legendary", "atk": 50, "cores": {}},
    {"name": "Blade of Abyss",          "tier": "legendary", "atk": 65, "cores": {}},
    {"name": "Celestial Flameblade",     "tier": "legendary", "atk": 55, "cores": {}},
    {"name": "Abyssal Reaper Scythe",   "tier": "legendary", "atk": 70, "cores": {}},
    {"name": "Worldender Greatsword",    "tier": "legendary", "atk": 85, "cores": {}},
    {"name": "Riftborn Executioner",     "tier": "legendary", "atk": 78, "cores": {}},


    {"name": "Shard Blade",              "tier": "mid",       "atk": 19, "cores": {}},
    {"name": "Void Cleaver",             "tier": "mid",       "atk": 21, "cores": {}},
    {"name": "Prism Sword",              "tier": "mid",       "atk": 22, "cores": {}},
    {"name": "Soulstealer Dagger",       "tier": "mid",       "atk": 20, "cores": {}, "lifesteal": True},
    {"name": "Fracture Greatsword",      "tier": "high",      "atk": 38, "cores": {}},
    {"name": "Dream Reaver",             "tier": "high",      "atk": 40, "cores": {}},
    {"name": "Shatterpoint Blade",       "tier": "high",      "atk": 42, "cores": {}},
    {"name": "Cursed Doomglaive",        "tier": "high",      "atk": 55, "cores": {}, "cursed": True},
    {"name": "Lucid Executioner",        "tier": "legendary", "atk": 72, "cores": {}},
    {"name": "Nightmare Scythe",         "tier": "legendary", "atk": 80, "cores": {}, "cursed": True},


    {"name": "Venomclaw",                "tier": "basic",     "atk": 8,  "cores": {}},
    {"name": "Splinter Axe",             "tier": "basic",     "atk": 9,  "cores": {}},
    {"name": "Rusted Pike",              "tier": "basic",     "atk": 10, "cores": {}},
    {"name": "Ashwood Bow",              "tier": "mid",       "atk": 16, "cores": {}},
    {"name": "Hexblade Saber",           "tier": "mid",       "atk": 18, "cores": {}},
    {"name": "Phantom Edge",             "tier": "mid",       "atk": 20, "cores": {}},
    {"name": "Crimson Battleaxe",        "tier": "high",      "atk": 33, "cores": {}},
    {"name": "Wraithfang Spear",         "tier": "high",      "atk": 37, "cores": {}},
    {"name": "Soulbrand Claymore",       "tier": "high",      "atk": 41, "cores": {}},
    {"name": "Thundercrack Hammer",      "tier": "high",      "atk": 44, "cores": {}},
    {"name": "Starbreaker Lance",        "tier": "legendary", "atk": 68, "cores": {}},
    {"name": "Omenblade",                "tier": "legendary", "atk": 75, "cores": {}},
    {"name": "The Last Word",            "tier": "legendary", "atk": 88, "cores": {}},
    {"name": "Dragonbone Cleaver",       "tier": "legendary", "atk": 92, "cores": {}},
    {"name": "Eternal Ruin",             "tier": "legendary", "atk": 100,"cores": {}, "cursed": True},


    {"name": "Boneshard Dagger",         "tier": "basic",     "atk": 7,   "cores": {}},
    {"name": "Ironwood Club",            "tier": "basic",     "atk": 9,   "cores": {}},
    {"name": "Twinblade",                "tier": "mid",       "atk": 17,  "cores": {}},
    {"name": "Crescent Falchion",        "tier": "mid",       "atk": 19,  "cores": {}},
    {"name": "Glacial Pike",             "tier": "high",      "atk": 35,  "cores": {}},
    {"name": "Abyssal Glaive",           "tier": "high",      "atk": 38,  "cores": {}},
    {"name": "Sunfire Sword",            "tier": "high",      "atk": 43,  "cores": {}},
    {"name": "World Ender",              "tier": "legendary", "atk": 110, "cores": {}, "cursed": True},
]

# =========================
# ARMOUR
# =========================

ARMOURS = [
    {"name": "Tattered Cloth",         "tier": "basic",     "def": 3,  "element": None},
    {"name": "Leather Vest",           "tier": "basic",     "def": 5,  "element": None},
    {"name": "Studded Leather",        "tier": "basic",     "def": 7,  "element": None},
    {"name": "Chainmail",              "tier": "mid",       "def": 11, "element": None},
    {"name": "Iron Plate",             "tier": "mid",       "def": 15, "element": None},
    {"name": "Boneguard Armour",       "tier": "mid",       "def": 13, "element": None},
    {"name": "Shadowweave Cloak",      "tier": "high",      "def": 20, "element": "shadow"},
    {"name": "Flameheart Breastplate", "tier": "high",      "def": 22, "element": "fire"},
    {"name": "Frostguard Armour",      "tier": "high",      "def": 25, "element": "ice"},
    {"name": "Thornplate",             "tier": "high",      "def": 23, "element": "nature"},
    {"name": "Voidplate",              "tier": "legendary", "def": 35, "element": "void"},
    {"name": "Celestial Vestment",     "tier": "legendary", "def": 40, "element": "light"},
    {"name": "Soul Shroud",            "tier": "legendary", "def": 45, "element": "soul"},
    {"name": "Abyssal Carapace",       "tier": "legendary", "def": 50, "element": "abyss"},
    {"name": "Creator's Mantle",       "tier": "legendary", "def": 60, "element": "creation"},


    {"name": "Shattered Plate",      "tier": "high",      "def": 28, "element": "void"},
    {"name": "Dreamweave Robe",      "tier": "high",      "def": 30, "element": "dream"},
    {"name": "Prismatic Barrier",    "tier": "legendary", "def": 52, "element": "crystal"},
    {"name": "Nightmare Shroud",     "tier": "legendary", "def": 48, "element": "shadow"},
    {"name": "Cursed Warplate",      "tier": "high",      "def": 35, "element": "void", "cursed": True},


    {"name": "Stormguard Mail",      "tier": "high",      "def": 27, "element": "storm"},
    {"name": "Death Shroud Armour",  "tier": "legendary", "def": 42, "element": "death"},
    {"name": "Titanwall Plate",      "tier": "legendary", "def": 55, "element": "titan"},
    {"name": "Cinderweave Robe",     "tier": "mid",       "def": 18, "element": "fire"},
    {"name": "Glacierborn Mail",     "tier": "high",      "def": 29, "element": "ice"},
    {"name": "Reaper's Coat",        "tier": "high",      "def": 31, "element": "death"},
]

# =========================

# LOOT ITEMS (SELLABLE)

# =========================

LOOT_ITEMS = [

    {"name": "Broken Relic", "value": 5},

    {"name": "Ancient Coin", "value": 15},

    {"name": "Cursed Bone", "value": 10},

    {"name": "Lost Amulet", "value": 25},

    {"name": "Soul Fragment", "value": 50},

    {"name": "Wolf Pelt", "value": 8},

    {"name": "Thorn Branch", "value": 6},

    {"name": "Ash Crystal", "value": 18},

    {"name": "Frozen Core", "value": 22},

    {"name": "Sea Pearl", "value": 20},

    {"name": "Iron Ore", "value": 15},

    {"name": "Swamp Toxin", "value": 18},

    {"name": "Shadow Essence", "value": 30},

    {"name": "Rift Shard", "value": 35},

    {"name": "Infernal Ember", "value": 40},

    {"name": "Celestial Dust", "value": 50},

    {"name": "Abyssal Soul", "value": 75},

    {"name": "Dragon Scale", "value": 80},

    {"name": "Titan Fragment", "value": 90},

    {"name": "Ancient Rune Stone", "value": 100},

    {"name": "Golden Idol", "value": 120},

    {"name": "Forgotten Crown", "value": 150},

    {"name": "Star Crystal", "value": 175},

    {"name": "World Fragment", "value": 200},

    {"name": "Divine Artifact", "value": 300},

]

# =========================

# MERCHANT SYSTEM (REGION-BASED ITEMS)

# =========================

MERCHANT_ITEMS = {
    "Whispering Woods": [
        "Rust-Eaten Blade", "Thorn Whip", "Flame Rune", "Nature Rune",
        "Staff of Flame", "Staff of Nature", "Leather Vest", "Studded Leather",
        "Iron", "Oak",
        "Oak Wood", "Ashwood", "Iron Ingot", "Nature Core"
    ],

    "Ashen Wastes": [
        "Ashen Longsword", "Cracked Hatchet", "Lightning Rune", "Magma Rune",
        "Staff of Lightning", "Magma Staff", "Studded Leather",
        "Emberwood", "Steel Ingot", "Molten Core", "Ember Core"
    ],

    "Frostbound Tundra": [
        "Frost-Touched Spear", "Ice Rune", "Glacial Rune",
        "Staff of Frost", "Frostguard Armour", "Chainmail",
        "Frostwood", "Moonwood", "Froststeel", "Titanium",
        "Glacier Core", "Lucid Core"
    ],

    "Crystal Spire": [
        "Stormweave Blade", "Quartz Rune", "Arcane Rune", "Crystal Rune",
        "Staff of Frost", "Crystal Staff", "Chainmail",
        "Crystalwood", "Crystal Alloy", "Starmetal",
        "Spire Core", "Star Core"
    ],

    "Sunken Coast": [
        "Obsidian Dagger", "Venomfang Blade", "Water Rune", "Ocean Rune",
        "Storm Staff", "Ocean Staff", "Chainmail", "Iron Plate",
        "Soulwood", "Dreamwood", "Lightsteel",
        "Ocean Core", "Celestial Core"
    ],

    "Ironpeak Mountains": [
        "Bone Cleaver", "Bonebreaker Mace", "Earth Rune", "Mountain Rune",
        "Magma Staff", "Iron Plate", "Boneguard Armour",
        "Iron Ingot", "Steel Ingot", "Ironbark", "Titanwood",
        "Iron Core"
    ],

    "Blight Swamp": [
        "Venomfang Blade", "Poison Rune", "Venom Rune",
        "Staff of Poison", "Venom Staff", "Thornplate",
        "Shadow Iron", "Voidwood", "Blight Core"
    ],

    "Shadow Vale": [
        "Shadow Reaver", "Voidthorn Dagger", "Shadow Rune", "Void Rune",
        "Void Staff", "Shadowweave Cloak", "Voidplate",
        "Shadowwood", "Voidwood", "Shadow Iron",
        "Shadow Core"
    ],

    "Crimson Depths": [
        "Ember-Forged Cleaver", "Infernal Waraxe", "Steel Rune",
        "Plasma Rune", "Ember Rune", "Magma Staff",
        "Flameheart Breastplate",
        "Crimson Steel", "Dragonwood", "Phoenixwood",
        "Molten Core", "Dragon Core", "Ember Core"
    ],

    "Riftlands": [
        "Riftborn Executioner", "Storm Rune", "Rift Rune",
        "Time Staff", "Space Staff", "Berserk Rune", "Wraith Rune",
        "Riftsteel", "Void Alloy", "Worldwood",
        "Anomaly Core", "Prism Core"
    ],

    "Infernal Depths": [
        "Soulpiercer Lance", "Magma Staff", "Void Rune",
        "Inferno Rune", "Sacrifice Rune", "Voidplate",
        "Infernium", "Soulsteel",
        "Hellfire Core"
    ],

    "Celestial Expanse": [
        "Celestial Flameblade", "Celestial Rune", "Astral Rune",
        "Celestial Staff", "Astral Staff", "Celestial Vestment",
        "Celestium", "Starmetal", "Crystalwood",
        "Star Core", "Celestial Core"
    ],

    "Shattered Wastes": [
        "Shard Blade", "Fracture Greatsword", "Void Rune",
        "Shard Rune", "Shard Staff", "Fracture Staff",
        "Shattered Plate", "Cursed Doomglaive",
        "Riftsteel", "Worldwood", "Crystalwood",
        "Anomaly Core", "Prism Core"
    ],

    "The Dreamscape": [
        "Dream Reaver", "Lucid Executioner", "Dream Rune",
        "Nightmare Rune", "Dreambreaker Staff", "Nightmare Shroud",
        "Dreamweave Robe",
        "Dreamwood", "Moonwood",
        "Lucid Core"
    ],

    "Abyss of Souls": [
        "Abyssal Reaper Scythe", "Worldender Greatsword",
        "Soul Rune", "Abyss Rune", "Abyssal Staff",
        "Soul Staff", "Abyssal Carapace", "Soul Shroud",
        "Abyssium", "Soulsteel", "Soulwood",
        "Abyss Core", "Soul Core"
    ],

    "Creator's Realm": [
        "Creator’s Blade", "Reality Forge Staff", "Existence Rune",
        "Mythroot", "Worldwood", "Creator Alloy",
        "Omnipotent Core"
    ]
}

REGION_ITEM_ELEMENTS = {
    "Whispering Woods": ["nature", "forest", "life"],
    "Ashen Wastes": ["fire", "magma", "demon", "phoenix", "solar", "shock", "lightning"],
    "Crimson Depths": ["fire", "magma", "plasma", "steel", "ember", "enhancer"],
    "Frostbound Tundra": ["ice", "frostfire", "lunar"],
    "Crystal Spire": ["ice", "crystal", "quartz", "arcane", "ethereal", "radiant"],
    "Sunken Coast": ["water", "ocean", "storm"],
    "Ironpeak Mountains": ["earth", "stone", "mountain", "metal"],
    "Blight Swamp": ["poison", "venom", "life"],
    "Shadow Vale": ["shadow", "void", "abyss", "nightmare"],
    "Riftlands": ["time", "space", "rift", "chaos", "mirror", "storm"],
    "Infernal Depths": ["fire", "magma", "demon", "abyss", "phoenix"],
    "Celestial Expanse": ["light", "celestial", "astral", "lunar", "solar", "angel", "cosmic"],
    "Abyss of Souls": ["soul", "death", "abyss", "void", "dream", "nightmare"],
    "Shattered Wastes": ["void", "crystal", "prism", "shard", "gravity", "chaos"],
    "The Dreamscape":   ["dream", "nightmare", "soul", "arcane", "shadow", "void"],
    "Creator's Realm": ["creation"],
}

# =========================
# STATUS EFFECT DEFINITIONS
# =========================

STATUS_EFFECTS = {
    "burn": {
        "type": "damage_over_time",
        "value": 5
    },
    "poison": {
        "type": "damage_over_time",
        "value": 4
    },
    "bleed": {
        "type": "damage_over_time",
        "value": 6
    },
    "freeze": {
        "type": "control",
        "effect": "skip_turn"
    },
    "stun": {
        "type": "control",
        "effect": "skip_turn"
    },
    "slow": {
        "type": "debuff",
        "effect": "reduce_speed"
    },
    "regen": {
        "type": "heal_over_time",
        "value": 5
    },
    "life_drain": {
        "type": "sustain",
        "value": 3
    },
    "void": {
        "type": "damage_over_time",
        "value": 8
    },
    "magma": {
        "type": "damage_over_time",
        "value": 10
    },
    "shock": {
        "type": "burst",
        "chance": 0.2
    },
}
SCROLLS = [

    # ================= BASIC =================

    {
        "name": "Scroll of Strength",
        "effect": "atk_up",
        "value": 5,
        "turns": 3
    },

    {
        "name": "Scroll of Fortitude",
        "effect": "def_up",
        "value": 5,
        "turns": 3
    },

    {
        "name": "Scroll of Haste",
        "effect": "speed_up",
        "value": 5,
        "turns": 3
    },

    {
        "name": "Scroll of Healing",
        "effect": "heal",
        "value": 50,
        "turns": 0
    },

    {
        "name": "Scroll of Luck",
        "effect": "luck_up",
        "value": 5,
        "turns": 5
    },

    # ================= ADVANCED =================

    {
        "name": "Scroll of Flames",
        "effect": "fire_weapon",
        "value": 8,
        "turns": 4
    },

    {
        "name": "Scroll of Frost",
        "effect": "ice_weapon",
        "value": 8,
        "turns": 4
    },

    {
        "name": "Scroll of Lightning",
        "effect": "shock_weapon",
        "value": 8,
        "turns": 4
    },

    {
        "name": "Scroll of Poison",
        "effect": "poison_weapon",
        "value": 8,
        "turns": 4
    },

    {
        "name": "Scroll of Regeneration",
        "effect": "regen",
        "value": 10,
        "turns": 5
    },

    # ================= ELITE =================

    {
        "name": "Scroll of Stone Skin",
        "effect": "massive_def_up",
        "value": 15,
        "turns": 5
    },

    {
        "name": "Scroll of Fury",
        "effect": "massive_atk_up",
        "value": 15,
        "turns": 3
    },

    {
        "name": "Scroll of Precision",
        "effect": "crit_up",
        "value": 10,
        "turns": 5
    },

    {
        "name": "Scroll of Resistance",
        "effect": "status_resist",
        "value": 10,
        "turns": 5
    },

    {
        "name": "Scroll of Mana Flow",
        "effect": "mana_regen",
        "value": 10,
        "turns": 5
    },

    # ================= LEGENDARY =================

    {
        "name": "Scroll of Time",
        "effect": "slow_time",
        "value": 20,
        "turns": 3
    },

    {
        "name": "Scroll of Void",
        "effect": "void_weapon",
        "value": 20,
        "turns": 4
    },

    {
        "name": "Scroll of Celestial Grace",
        "effect": "heal_over_time",
        "value": 20,
        "turns": 5
    },

    {
        "name": "Scroll of Reality Shift",
        "effect": "dodge_up",
        "value": 20,
        "turns": 5
    },

    {
        "name": "Scroll of Immortality",
        "effect": "death_save",
        "value": 1,
        "turns": 1
    }
]
# =========================================================
# ELEMENTAL CIVILIZATIONS
# =========================================================

ELEMENTAL_VILLAGES = {
    "Infernal Depths": {
        "name": "Ignar Clan",
        "core": "Ignar Fire Core",
        "element": "fire",
        "icon": "🔥",
        "desc": "A fierce clan of fire elementals who have mastered combustion magic deep in the volcanic depths.",
        "boss_key": "ignar_prime",
    },
    "Frostbound Tundra": {
        "name": "Glacien Tribe",
        "core": "Glacien Ice Core",
        "element": "ice",
        "icon": "❄️",
        "desc": "Ancient ice-shapers who dwell within glacial cathedrals carved from eternal permafrost.",
        "boss_key": "glacien_ancient",
    },
    "Crystal Spire": {
        "name": "Voltis Enclave",
        "core": "Voltis Storm Core",
        "element": "storm",
        "icon": "⚡",
        "desc": "A secretive order that channels raw lightning through the crystal spires as conduits.",
        "boss_key": "voltis_archon",
    },
    "Whispering Woods": {
        "name": "Sylvar Circle",
        "core": "Sylvar Nature Core",
        "element": "nature",
        "icon": "🌿",
        "desc": "Ancient druids bound to the living forest, guardians of the primordial seed of life.",
        "boss_key": "sylvar_elder",
    },
}

ELEMENTAL_BOSSES = {
    "ignar_prime": {
        "name": "Ignar Prime",
        "hp": 2800, "atk": 280, "def": 90,
        "element": "fire", "icon": "🔥",
        "phases": 4,
        "status_effect": "burn",
        "status_dmg": 20,
        "status_every": 1,
        "drop": "Ignar Fire Core",
        "taunt": "FEEL THE ETERNAL FLAME!",
    },
    "glacien_ancient": {
        "name": "Glacien Ancient",
        "hp": 2000, "atk": 250, "def": 95,
        "element": "ice", "icon": "❄️",
        "phases": 4,
        "status_effect": "freeze",
        "status_dmg": 0,
        "status_every": 2,
        "drop": "Glacien Ice Core",
        "taunt": "YOUR BLOOD SHALL FREEZE IN YOUR VEINS.",
    },
    "voltis_archon": {
        "name": "Voltis Archon",
        "hp": 2100, "atk": 260, "def": 75,
        "element": "storm", "icon": "⚡",
        "phases": 4,
        "status_effect": "shock",
        "status_dmg": 40,
        "status_every": 1,
        "drop": "Voltis Storm Core",
        "taunt": "THE STORM ANSWERS TO ME ALONE!",
    },
    "sylvar_elder": {
        "name": "Sylvar Elder",
        "hp": 1800, "atk": 230, "def": 80,
        "element": "nature", "icon": "🌿",
        "phases": 3,
        "status_effect": "poison",
        "status_dmg": 12,
        "status_every": 1,
        "drop": "Sylvar Nature Core",
        "taunt": "The forest does not forgive intruders.",
    },
}

ELEMENTAL_CORES = {
    "Ignar Fire Core": {
        "element": "fire",
        "bonus_atk": 20,
        "on_hit_effect": "burn",
        "desc": "A pulsing ember-core forged by the Ignar Clan. Infuses searing fire into any weapon or staff.",
    },
    "Glacien Ice Core": {
        "element": "ice",
        "bonus_atk": 18,
        "on_hit_effect": "freeze",
        "desc": "A shard of eternal winter from the Glacien Tribe. Freezes enemies solid on hit.",
    },
    "Voltis Storm Core": {
        "element": "storm",
        "bonus_atk": 22,
        "on_hit_effect": "shock",
        "desc": "A crackling orb of compressed lightning from the Voltis Enclave. Unleashes chain lightning on hit.",
    },
    "Sylvar Nature Core": {
        "element": "nature",
        "bonus_atk": 16,
        "on_hit_effect": "poison",
        "desc": "A verdant seed of primordial energy from the Sylvar Circle. Poisons enemies and grants trickle-healing.",
    },
}

CORE_STABILISER = {
    "name": "Core Stabiliser",
    "value": 500,
    "desc": "A rift-forged device that anchors elemental cores safely into weapons and staffs without shattering them.",
}


# =========================================================
# REGION STRUCTURES (2-3 per region)
# =========================================================

REGION_STRUCTURES = {
    "Whispering Woods": [
        {"name": "Old Village",       "type": "village", "icon": "🏘"},
        {"name": "Druid Ruins",        "type": "ruins",   "icon": "🗿"},
        {"name": "Nature Shrine",      "type": "shrine",  "icon": "⛪"},
    ],
    "Ashen Wastes": [
        {"name": "Scorched Village",   "type": "village", "icon": "🏘"},
        {"name": "Ember Tower",        "type": "tower",   "icon": "🗼"},
        {"name": "Ash Catacombs",      "type": "dungeon", "icon": "🏰"},
    ],
    "Crimson Depths": [
        {"name": "Smiths' Quarter",    "type": "village", "icon": "🏘"},
        {"name": "Forge Ruins",        "type": "ruins",   "icon": "🗿"},
        {"name": "Magma Vault",        "type": "dungeon", "icon": "🏰"},
    ],
    "Frostbound Tundra": [
        {"name": "Ice Hamlet",         "type": "village", "icon": "🏘"},
        {"name": "Frozen Shrine",      "type": "shrine",  "icon": "⛪"},
        {"name": "Glacier Dungeon",    "type": "dungeon", "icon": "🏰"},
    ],
    "Crystal Spire": [
        {"name": "Crystal Village",    "type": "village", "icon": "🏘"},
        {"name": "Prism Tower",        "type": "tower",   "icon": "🗼"},
        {"name": "Arcane Ruins",       "type": "ruins",   "icon": "🗿"},
    ],
    "Sunken Coast": [
        {"name": "Dockside Village",   "type": "village", "icon": "🏘"},
        {"name": "Sunken Shrine",      "type": "shrine",  "icon": "⛪"},
        {"name": "Tidal Cavern",       "type": "dungeon", "icon": "🏰"},
    ],
    "Ironpeak Mountains": [
        {"name": "Mountain Village",   "type": "village", "icon": "🏘"},
        {"name": "Iron Watchtower",    "type": "tower",   "icon": "🗼"},
        {"name": "Peak Ruins",         "type": "ruins",   "icon": "🗿"},
    ],
    "Blight Swamp": [
        {"name": "Rotwood Village",    "type": "village", "icon": "🏘"},
        {"name": "Plague Shrine",      "type": "shrine",  "icon": "⛪"},
        {"name": "Blight Dungeon",     "type": "dungeon", "icon": "🏰"},
    ],
    "Shadow Vale": [
        {"name": "Shadow Hamlet",      "type": "village", "icon": "🏘"},
        {"name": "Void Tower",         "type": "tower",   "icon": "🗼"},
        {"name": "Dark Ruins",         "type": "ruins",   "icon": "🗿"},
    ],
    "Infernal Depths": [
        {"name": "Ember Village",      "type": "village", "icon": "🏘"},
        {"name": "Hell Shrine",        "type": "shrine",  "icon": "⛪"},
        {"name": "Infernal Dungeon",   "type": "dungeon", "icon": "🏰"},
    ],
    "Celestial Expanse": [
        {"name": "Starfall Village",   "type": "village", "icon": "🏘"},
        {"name": "Celestial Shrine",   "type": "shrine",  "icon": "⛪"},
        {"name": "Astral Ruins",       "type": "ruins",   "icon": "🗿"},
    ],
    "Riftlands": [
        {"name": "Rift Outpost",       "type": "village", "icon": "🏘"},
        {"name": "Anomaly Tower",      "type": "tower",   "icon": "🗼"},
        {"name": "Source Temple",      "type": "special", "icon": "🌌"},
    ],
    "Abyss of Souls": [
        {"name": "Lost Village",       "type": "village", "icon": "🏘"},
        {"name": "Soul Shrine",        "type": "shrine",  "icon": "⛪"},
        {"name": "Abyssal Dungeon",    "type": "dungeon", "icon": "🏰"},
    ],
    "Shattered Wastes": [
        {"name": "Shard Outpost",      "type": "village", "icon": "🏘"},
        {"name": "Fracture Tower",     "type": "tower",   "icon": "🗼"},
        {"name": "Prism Dungeon",      "type": "dungeon", "icon": "🏰"},
    ],
    "The Dreamscape": [
        {"name": "Lucid Village",      "type": "village", "icon": "🏘"},
        {"name": "Dream Shrine",       "type": "shrine",  "icon": "⛪"},
        {"name": "Nightmare Vault",    "type": "dungeon", "icon": "🏰"},
    ],
    "Creator's Realm": [
        {"name": "Divine Sanctum",     "type": "shrine",  "icon": "⛪"},
        {"name": "Creator's Vault",    "type": "dungeon", "icon": "🏰"},
    ],
}

# =========================================================
# FOOD ITEMS
# =========================================================

FOOD_ITEMS = [
    {"name": "mineral stew",        "hunger": 12, "value": 25},
    {"name": "Bread Loaf",          "hunger": 20, "value": 15},
    {"name": "Forest Berries",      "hunger": 15, "value": 10},
    {"name": "Roasted Meat",        "hunger": 35, "value": 25},
    {"name": "Dried Fish",          "hunger": 25, "value": 20},
    {"name": "Hearty Stew",         "hunger": 50, "value": 40},
    {"name": "Traveller's Ration",  "hunger": 30, "value": 25},
    {"name": "Ember Bread",         "hunger": 25, "value": 20},
    {"name": "Frost Berry Jam",     "hunger": 20, "value": 15},
    {"name": "Warrior's Meal",      "hunger": 60, "value": 60},
    {"name": "Soul Feast",          "hunger": 100,"value": 120},
    {"name": "Swamp Mushroom",      "hunger": 18, "value": 12},
    {"name": "Celestial Fruit",     "hunger": 45, "value": 50},
    {"name": "Infernal Jerky",      "hunger": 35, "value": 30},
    {"name": "Abyssal Broth",       "hunger": 70, "value": 80},

    {"name": "Void Candy",          "hunger": 10,  "value": 8},
    {"name": "Wanderer's Biscuit",  "hunger": 22,  "value": 18},
    {"name": "Shadowfruit",         "hunger": 28,  "value": 22},
    {"name": "Crystal Nectar",      "hunger": 40,  "value": 45},
    {"name": "Shard Soup",          "hunger": 35,  "value": 30},
    {"name": "Dream Cake",          "hunger": 55,  "value": 65},
    {"name": "Titan Steak",         "hunger": 80,  "value": 100},
    {"name": "Elixir of Life",      "hunger": 100, "value": 200, "also_heal": 50},


    {"name": "Bone Broth",          "hunger": 30,  "value": 25},
    {"name": "Storm Berry",         "hunger": 18,  "value": 15},
    {"name": "Dragonfruit Slice",   "hunger": 60,  "value": 75},
    {"name": "Void Mushroom",       "hunger": 45,  "value": 50},
]

# Which food + gear each village type sells (3-5 food + 2-3 gear per region)
VILLAGE_STOCK = {
    "Whispering Woods": {
        "food": ["Bread Loaf", "Forest Berries", "Roasted Meat"],
        "gear": ["Rust-Eaten Blade", "Thorn Whip", "Leather Vest", "Nature Rune"],
    },
    "Ashen Wastes": {
        "food": ["Ember Bread", "Roasted Meat", "Dried Fish"],
        "gear": ["Ashen Longsword", "Cracked Hatchet", "Studded Leather", "Flame Rune"],
    },
    "Crimson Depths": {
        "food": ["Ember Bread", "Warrior's Meal", "Roasted Meat"],
        "gear": ["Ember-Forged Cleaver", "Flameheart Breastplate", "Steel Rune"],
    },
    "Frostbound Tundra": {
        "food": ["Frost Berry Jam", "Hearty Stew", "Traveller's Ration"],
        "gear": ["Frost-Touched Spear", "Frostguard Armour", "Ice Rune"],
    },
    "Crystal Spire": {
        "food": ["Frost Berry Jam", "mineral stew", "Traveller's Ration"],
        "gear": ["Stormweave Blade", "Chainmail", "Crystal Rune", "Arcane Rune"],
    },
    "Sunken Coast": {
        "food": ["Dried Fish", "Hearty Stew", "Forest Berries"],
        "gear": ["Obsidian Dagger", "Chainmail", "Water Rune", "Storm Staff"],
    },
    "Ironpeak Mountains": {
        "food": ["Roasted Meat", "Hearty Stew", "Warrior's Meal"],
        "gear": ["Bonebreaker Mace", "Iron Plate", "Earth Rune", "Mountain Rune"],
    },
    "Blight Swamp": {
        "food": ["Swamp Mushroom", "Dried Fish", "Traveller's Ration"],
        "gear": ["Venomfang Blade", "Thornplate", "Poison Rune", "Venom Rune"],
    },
    "Shadow Vale": {
        "food": ["Hearty Stew", "Roasted Meat", "Warrior's Meal"],
        "gear": ["Shadow Reaver", "Shadowweave Cloak", "Shadow Rune", "Void Rune"],
    },
    "Infernal Depths": {
        "food": ["Infernal Jerky", "Ember Bread", "Warrior's Meal"],
        "gear": ["Soulpiercer Lance", "Voidplate", "Inferno Rune"],
    },
    "Celestial Expanse": {
        "food": ["Celestial Fruit", "Soul Feast", "Hearty Stew"],
        "gear": ["Celestial Flameblade", "Celestial Vestment", "Celestial Rune"],
    },
    "Riftlands": {
        "food": ["Traveller's Ration", "Warrior's Meal", "Hearty Stew"],
        "gear": ["Riftborn Executioner", "Berserk Rune", "Rift Rune", "Time Staff"],
    },
    "Abyss of Souls": {
        "food": ["Abyssal Broth", "Soul Feast", "Warrior's Meal"],
        "gear": ["Abyssal Reaper Scythe", "Soul Shroud", "Soul Rune", "Abyss Rune"],
    },
    "Shattered Wastes": {
        "food": ["Warrior's Meal", "Hearty Stew", "Roasted Meat"],
        "gear": ["Shard Blade", "Fracture Greatsword", "Shattered Plate", "Shard Rune"],
    },
    "The Dreamscape": {
        "food": ["Soul Feast", "Celestial Fruit", "Abyssal Broth"],
        "gear": ["Dream Reaver", "Dreamweave Robe", "Dream Rune", "Nightmare Shroud"],
    },
    "Creator's Realm": {
        "food": ["Soul Feast", "Celestial Fruit", "Abyssal Broth"],
        "gear": ["Worldender Greatsword", "Creator's Mantle"],
    },
}


# =========================================================
# CHARACTER CLASSES
# =========================================================

CLASSES = {
    "warrior": {
        "name": "Warrior", "icon": "⚔",
        "desc": "Tough melee brawler. High HP and DEF. Can counter-attack after taking a hit.",
        "bonus": {"hp": 30, "max_hp": 30, "atk": 5, "def": 3},
        "passive": "counter",
        "passive_desc": "15% chance to counter-attack for 50% weapon damage after taking a hit",
        "skill_name": "Shield Bash", "skill_cd": 3,
        "skill_desc": "Stun the enemy for 1 turn",
    },
    "mage": {
        "name": "Mage", "icon": "🔮",
        "desc": "Arcane scholar. Mana-rich, all spell damage boosted.",
        "bonus": {"mana": 30, "atk": 3, "max_hp": 10, "hp": 10},
        "passive": "spell_boost",
        "passive_desc": "All spell and staff damage +30%",
        "skill_name": "Arcane Surge", "skill_cd": 3,
        "skill_desc": "Your next attack hits twice",
    },
    "rogue": {
        "name": "Rogue", "icon": "🗡",
        "desc": "Fast and deadly. High speed and a 15% crit chance on weapon hits.",
        "bonus": {"speed": 15, "atk": 5},
        "passive": "crit",
        "passive_desc": "15% chance to deal double damage on weapon hits",
        "skill_name": "Expose Weakness", "skill_cd": 3,
        "skill_desc": "Reduce enemy DEF by 6 for 3 turns",
    },
    "ranger": {
        "name": "Ranger", "icon": "🏹",
        "desc": "Mobile and adaptable. 25% chance of a free ranged shot each turn.",
        "bonus": {"speed": 10, "atk": 3, "hp": 15, "max_hp": 15},
        "passive": "ranger_shot",
        "passive_desc": "25% chance to deal a free 15-damage shot after attacking",
        "skill_name": "Volley", "skill_cd": 4,
        "skill_desc": "Unload 3 arrows for 15 damage each",
    },
    "necromancer": {
        "name": "Necromancer", "icon": "💀",
        "desc": "Dark arts practitioner. Drains life with every strike.",
        "bonus": {"atk": 4, "def": 2, "mana": 20},
        "passive": "lifesteal",
        "passive_desc": "Heal 20% of all weapon damage dealt",
        "skill_name": "Soul Rip", "skill_cd": 3,
        "skill_desc": "Drain 35 HP directly from the enemy",
    },
}

# =========================================================
# SKILL TREE
# =========================================================

SKILLS = {
    "iron_skin":         {"name": "Iron Skin",         "pts": 1, "desc": "+4 DEF permanently"},
    "battle_hardened":   {"name": "Battle Hardened",   "pts": 1, "desc": "+20 max HP permanently"},
    "swift_feet":        {"name": "Swift Feet",         "pts": 1, "desc": "+8 speed (more dodge chance)"},
    "assassin":          {"name": "Assassin",           "pts": 2, "desc": "+10% bonus crit chance on top of class"},
    "vampiric_strike":   {"name": "Vampiric Strike",    "pts": 2, "desc": "Heal 15% of weapon damage dealt"},
    "hunger_resist":     {"name": "Hunger Resist",      "pts": 1, "desc": "Hunger drains 50% slower"},
    "dungeon_delver":    {"name": "Dungeon Delver",     "pts": 1, "desc": "+30% souls gained from all sources"},
    "berserk":           {"name": "Berserk",            "pts": 2, "desc": "ATK +50% when your HP is below 30%"},
    "companion_bond":    {"name": "Companion Bond",     "pts": 2, "desc": "Companion passive hits deal double damage"},
    "elemental_mastery": {"name": "Elemental Mastery",  "pts": 2, "desc": "Elemental status effects last +2 extra turns"},
    "resilience":        {"name": "Resilience",         "pts": 2, "desc": "Reduce all incoming damage by 10%"},
    "soul_harvest":      {"name": "Soul Harvest",       "pts": 2, "desc": "+50% XP from all kills"},
}

# =========================================================
# QUEST TEMPLATES
# =========================================================

QUEST_TEMPLATES = [
    {
        "type": "kill_enemies",
        "desc": "Slay {n} enemies in {region}",
        "n_range": (3, 8),
        "reward_souls": 150,
        "reward_item": None,
    },
    {
        "type": "kill_enemies",
        "desc": "Hunt down {n} creatures in {region}",
        "n_range": (5, 10),
        "reward_souls": 220,
        "reward_item": "Roasted Meat",
    },
    {
        "type": "boss_kill",
        "desc": "Defeat the boss of {region}",
        "n_range": (1, 1),
        "reward_souls": 350,
        "reward_item": "Warrior's Meal",
    },
    {
        "type": "explore_structure",
        "desc": "Explore any ruin or dungeon in {region}",
        "n_range": (1, 1),
        "reward_souls": 120,
        "reward_item": "Traveller's Ration",
    },
    {
        "type": "reach_region",
        "desc": "Travel to {target_region}",
        "n_range": (1, 1),
        "reward_souls": 200,
        "reward_item": "Hearty Stew",
    },
    {
        "type": "earn_souls",
        "desc": "Gather {n} souls (current run)",
        "n_range": (100, 400),
        "reward_souls": 80,
        "reward_item": "Bread Loaf",
    },
]

# Companion move names and descriptions keyed by element
COMPANION_MOVES = {
    "fire":    {"name": "Inferno Burst",  "desc": "30 fire damage + burn 3 turns",           },
    "ice":     {"name": "Frost Nova",     "desc": "25 ice damage + freeze 2 turns",           },
    "water":   {"name": "Tidal Wave",     "desc": "20 damage + enemy DEF -4 for 3 turns",     },
    "earth":   {"name": "Stone Wall",     "desc": "Your DEF +5 for 3 turns",                  },
    "poison":  {"name": "Venom Barrage",  "desc": "15 damage + poison 4 turns",               },
    "shadow":  {"name": "Shadowstep",     "desc": "20 damage + blind enemy 2 turns",          },
    "void":    {"name": "Void Rift",      "desc": "28 damage + void 3 turns",                 },
    "light":   {"name": "Holy Light",     "desc": "Heal you for 30 HP",                       },
    "nature":  {"name": "Entangle",       "desc": "Root enemy 2 turns (reduced damage)",      },
    "soul":    {"name": "Soul Drain",     "desc": "Drain 25 HP from enemy to you",            },
    "storm":   {"name": "Chain Lightning","desc": "35 shock damage",                          },
    "arcane":  {"name": "Arcane Bolt",    "desc": "30 arcane damage + random debuff",         },
}


# =========================================================
# WEATHER SYSTEM
# =========================================================

WEATHER_EFFECTS = {
    "Clear":      {"desc": "The air is still and clear.",              "player_dmg_mod": 1.00, "enemy_dmg_mod": 1.00, "loot_mod": 1.0, "icon": "☀"},
    "Stormy":     {"desc": "Thunder rolls across the sky.",            "player_dmg_mod": 1.10, "enemy_dmg_mod": 1.15, "loot_mod": 1.1, "icon": "⛈"},
    "Foggy":      {"desc": "A thick fog muffles your senses.",         "player_dmg_mod": 0.90, "enemy_dmg_mod": 0.85, "loot_mod": 0.9, "icon": "🌫"},
    "Blazing":    {"desc": "Scorching heat beats down on you.",        "player_dmg_mod": 1.20, "enemy_dmg_mod": 1.10, "loot_mod": 1.0, "icon": "🌡"},
    "Blizzard":   {"desc": "Biting cold numbs your limbs.",            "player_dmg_mod": 0.85, "enemy_dmg_mod": 1.20, "loot_mod": 1.2, "icon": "❄"},
    "Void Storm": {"desc": "Reality fractures and warps around you.",  "player_dmg_mod": 1.15, "enemy_dmg_mod": 1.25, "loot_mod": 1.5, "icon": "🌀"},
}

# =========================================================
# RANDOM WANDER EVENTS
# =========================================================

WANDER_EVENTS = [
    {
        "id": "wandering_merchant",
        "title": "Wandering Merchant",
        "desc": "🛒 A hooded merchant steps from the shadows with wares to trade.",
        "weight": 15,
    },
    {
        "id": "mysterious_altar",
        "title": "Mysterious Altar",
        "desc": "🗿 A stone altar pulses with ancient energy. Something was offered here.",
        "weight": 10,
    },
    {
        "id": "lucky_cache",
        "title": "Lucky Cache",
        "desc": "💰 Half-buried under debris — a traveller's lost satchel!",
        "weight": 20,
    },
    {
        "id": "cursed_chest",
        "title": "Cursed Chest",
        "desc": "⚠  A black iron chest chains with glowing runes. The air tastes of danger.",
        "weight": 8,
    },
    {
        "id": "bandit_ambush",
        "title": "Bandit Ambush",
        "desc": "🗡 A gang of desperate bandits leaps from the treeline!",
        "weight": 12,
    },
    {
        "id": "wounded_traveller",
        "title": "Wounded Traveller",
        "desc": "💬 A bloodied stranger calls out — 'Please, help me...'",
        "weight": 10,
    },
]

# =========================================================
# ACHIEVEMENT SYSTEM
# =========================================================

ACHIEVEMENTS = [
    {"id": "first_blood",  "name": "First Blood",    "desc": "Win your first fight",            "type": "wander_count",   "threshold": 1},
    {"id": "wanderer",     "name": "Wanderer",        "desc": "Wander 50 times",                 "type": "wander_count",   "threshold": 50},
    {"id": "explorer",     "name": "Explorer",        "desc": "Unlock 5 regions",                "type": "unlocked_count", "threshold": 5},
    {"id": "boss_slayer",  "name": "Boss Slayer",     "desc": "Defeat your first boss",          "type": "boss_count",     "threshold": 1},
    {"id": "decimator",    "name": "Decimator",       "desc": "Defeat 5 bosses",                 "type": "boss_count",     "threshold": 5},
    {"id": "rich",         "name": "Soul Hoarder",    "desc": "Hold 1000 souls at once",         "type": "gold",           "threshold": 1000},
    {"id": "veteran",      "name": "Veteran",         "desc": "Reach level 10",                  "type": "level",          "threshold": 10},
    {"id": "legendary",    "name": "Legendary",       "desc": "Reach level 20",                  "type": "level",          "threshold": 20},
    {"id": "collector",    "name": "Collector",       "desc": "Own 5 weapons",                   "type": "weapon_count",   "threshold": 5},
    {"id": "adventurer",   "name": "Adventurer",      "desc": "Discover 5 structures",           "type": "struct_count",   "threshold": 5},
    {"id": "elementalist", "name": "Elementalist",    "desc": "Collect 3 elemental cores",       "type": "core_count",     "threshold": 3},
    {"id": "skilled",      "name": "Skilled",         "desc": "Learn 5 passive skills",          "type": "skill_count",    "threshold": 5},
]

# Achievement-id → title granted
ACHIEVEMENT_TITLES = {
    "first_blood":  "Blooded",
    "wanderer":     "The Wanderer",
    "explorer":     "Pathfinder",
    "boss_slayer":  "Bossbreaker",
    "decimator":    "Titan Slayer",
    "rich":         "Soul Baron",
    "veteran":      "Veteran",
    "legendary":    "Legend",
    "collector":    "Armoury Master",
    "adventurer":   "Dungeon Delver",
    "elementalist": "Elementalist",
    "skilled":      "Master of Skills",
}

# =========================================================
# BOUNTY SYSTEM
# =========================================================

BOUNTY_MONSTERS = {
    "Whispering Woods":   {"name": "Old Thornback",    "hp": 120, "atk": 25, "def": 8,  "reward": 250},
    "Ashen Wastes":       {"name": "Blazebeast Rex",   "hp": 140, "atk": 30, "def": 10, "reward": 300},
    "Crimson Depths":      {"name": "The Ironbreaker",  "hp": 160, "atk": 35, "def": 14, "reward": 320},
    "Frostbound Tundra":  {"name": "Icefang",          "hp": 150, "atk": 28, "def": 12, "reward": 300},
    "Crystal Spire":      {"name": "Glass Tyrant",     "hp": 170, "atk": 32, "def": 15, "reward": 340},
    "Sunken Coast":       {"name": "The Drowned King", "hp": 180, "atk": 34, "def": 13, "reward": 360},
    "Ironpeak Mountains": {"name": "Stonecrusher",     "hp": 190, "atk": 36, "def": 16, "reward": 380},
    "Blight Swamp":       {"name": "Plaguelord",       "hp": 200, "atk": 38, "def": 17, "reward": 400},
    "Shadow Vale":        {"name": "Voidhunter",       "hp": 210, "atk": 40, "def": 18, "reward": 420},
    "Shattered Wastes":   {"name": "The Prism Tyrant", "hp": 220, "atk": 42, "def": 19, "reward": 450},
    "Infernal Depths":    {"name": "Hellwarden",       "hp": 230, "atk": 44, "def": 20, "reward": 480},
    "Celestial Expanse":  {"name": "The Fallen Angel", "hp": 240, "atk": 46, "def": 21, "reward": 500},
    "Riftlands":          {"name": "Rift Horror",      "hp": 260, "atk": 48, "def": 22, "reward": 540},
    "The Dreamscape":     {"name": "The Lucid King",   "hp": 280, "atk": 50, "def": 24, "reward": 600},
    "Abyss of Souls":     {"name": "Soul Overlord",    "hp": 300, "atk": 52, "def": 26, "reward": 700},
}

# =========================================================
# POTION CRAFTING
# =========================================================

POTION_RECIPES = [
    {
        "name": "Health Potion",
        "desc": "Restores 50 HP",
        "cost": 80,
        "effect": "heal_50",
        "ingredients_hint": "Crafted at village workbench (80 souls)",
    },
    {
        "name": "Greater Elixir",
        "desc": "Restores 120 HP",
        "cost": 180,
        "effect": "heal_120",
        "ingredients_hint": "Crafted at village workbench (180 souls)",
    },
    {
        "name": "Antidote",
        "desc": "Cures poison and burn",
        "cost": 60,
        "effect": "cure_status",
        "ingredients_hint": "Crafted at village workbench (60 souls)",
    },
    {
        "name": "Strength Draught",
        "desc": "+10 ATK for 3 fights",
        "cost": 200,
        "effect": "atk_boost",
        "ingredients_hint": "Crafted at village workbench (200 souls)",
    },
    {
        "name": "Elixir of Fortune",
        "desc": "+20% loot quality for next 5 explores",
        "cost": 250,
        "effect": "luck_boost",
        "ingredients_hint": "Crafted at village workbench (250 souls)",
    },
]


# =========================
# WORLD EVENTS 
# =========================
WORLD_EVENTS = [
    {
        "name":     "Blood Moon",
        "icon":     "🩸",
        "desc":     "A crimson moon stains the sky. Enemies hit harder but bleed gold.",
        "enemy_atk_mod": 1.3,
        "enemy_hp_mod":  1.0,
        "gold_mod":      1.5,
        "xp_mod":        1.0,
    },
    {
        "name":     "Void Surge",
        "icon":     "🌀",
        "desc":     "Void energy tears through reality. All Void creatures are empowered.",
        "enemy_atk_mod": 1.2,
        "enemy_hp_mod":  1.4,
        "gold_mod":      1.2,
        "xp_mod":        1.3,
    },
    {
        "name":     "Soul Eclipse",
        "icon":     "🌑",
        "desc":     "The sun is swallowed. XP flows freely from the darkness.",
        "enemy_atk_mod": 0.9,
        "enemy_hp_mod":  1.0,
        "gold_mod":      1.0,
        "xp_mod":        2.0,
    },
    {
        "name":     "Titan's Wrath",
        "icon":     "⚡",
        "desc":     "Ancient giants stir. Enemies grow massive but their gold hoards grow with them.",
        "enemy_atk_mod": 1.5,
        "enemy_hp_mod":  1.5,
        "gold_mod":      2.0,
        "xp_mod":        1.5,
    },
    {
        "name":     "Soulstorm",
        "icon":     "🌪️",
        "desc":     "Howling spirits fill the air. Combat is chaotic — anything can happen.",
        "enemy_atk_mod": 1.1,
        "enemy_hp_mod":  0.8,
        "gold_mod":      1.3,
        "xp_mod":        1.2,
    },
    {
        "name":     "Radiant Dawn",
        "icon":     "☀️",
        "desc":     "Pure light floods the land. Enemies are weakened, heroes are blessed.",
        "enemy_atk_mod": 0.75,
        "enemy_hp_mod":  0.85,
        "gold_mod":      1.0,
        "xp_mod":        1.1,
    },
    {
        "name":     "Cursed Hour",
        "icon":     "💀",
        "desc":     "An ancient curse grips the world. Every battle risks a deadly hex.",
        "enemy_atk_mod": 1.4,
        "enemy_hp_mod":  1.2,
        "gold_mod":      1.8,
        "xp_mod":        1.6,
    },
    {
        "name":     "The Dreaming",
        "icon":     "💤",
        "desc":     "Reality blurs. Enemies may randomly fall asleep mid-combat.",
        "enemy_atk_mod": 1.0,
        "enemy_hp_mod":  1.1,
        "gold_mod":      1.1,
        "xp_mod":        1.4,
    },
]

# =========================
# GEAR SETS 
# =========================
GEAR_SETS = {
    "Void Destroyer": {
        "icon":    "🌀",
        "desc":    "Channel the void's endless hunger.",
        "pieces":  {"weapon": "Voidbreaker Edge", "armour": "Voidplate", "rune": "Void Rune"},
        "bonus":   {"atk": 30, "def": 15, "label": "+30 ATK, +15 DEF, Void immunity"},
    },
    "Storm Tyrant": {
        "icon":    "⚡",
        "desc":    "Ride the lightning.",
        "pieces":  {"weapon": "Thundercrack Hammer", "armour": "Stormguard Mail", "rune": "Tempest Rune II"},
        "bonus":   {"atk": 25, "def": 10, "hp": 40, "label": "+25 ATK, +10 DEF, +40 HP"},
    },
    "Death's Herald": {
        "icon":    "💀",
        "desc":    "Become death itself.",
        "pieces":  {"weapon": "Omenblade", "armour": "Death Shroud Armour", "rune": "Oblivion Rune"},
        "bonus":   {"atk": 40, "def": 5, "crit": True, "label": "+40 ATK, +5 DEF, guaranteed crit every 4th hit"},
    },
    "Titan's Endurance": {
        "icon":    "🏔️",
        "desc":    "Immovable as the ancient mountains.",
        "pieces":  {"weapon": "Dragonbone Cleaver", "armour": "Titanwall Plate", "rune": "Titan's Grip Rune"},
        "bonus":   {"atk": 15, "def": 30, "hp": 80, "label": "+15 ATK, +30 DEF, +80 HP"},
    },
}

# =========================
# WEAPON FUSION RECIPES
# =========================
FUSION_RECIPES = [
    {
        "name":   "Soul Riven Blade",
        "tier":   "legendary",
        "atk":    95,
        "needs":  ["Omenblade", "Soulbrand Claymore"],
        "desc":   "Two cursed blades merged into one instrument of annihilation.",
        "cores":  {},
    },
    {
        "name":   "Voidstorm Edge",
        "tier":   "legendary",
        "atk":    88,
        "needs":  ["Voidbreaker Edge", "Thundercrack Hammer"],
        "desc":   "Void energy and storm force fused in perfect violent harmony.",
        "cores":  {},
    },
    {
        "name":   "Dragon's Last Breath",
        "tier":   "legendary",
        "atk":    105,
        "needs":  ["Dragonbone Cleaver", "Starbreaker Lance"],
        "desc":   "The ultimate weapon. It hums with the fury of a dying dragon.",
        "cores":  {},
    },
    {
        "name":   "The Oblivion",
        "tier":   "legendary",
        "atk":    120,
        "needs":  ["Eternal Ruin", "The Last Word"],
        "desc":   "What remains when two cursed weapons devour each other.",
        "cores":  {},
        "cursed": True,
    },
    {
        "name":   "Phantom Wraith",
        "tier":   "high",
        "atk":    58,
        "needs":  ["Phantom Edge", "Wraithfang Spear"],
        "desc":   "Ghost-steel and wraith-bone bound together.",
        "cores":  {},
    },
]




# =========================================================
# INGREDIENTS — found while wandering each region
# =========================================================

REGION_INGREDIENTS = {
    "Whispering Woods":   ["Thorn Petal", "Forest Mushroom", "Dew Blossom", "Vine Root"],
    "Ashen Wastes":       ["Ember Root", "Ash Dust", "Cinder Shard", "Scorched Bark"],
    "Crimson Depths":      ["Magma Crystal", "Iron Dust", "Forge Cinder", "Slag Chunk"],
    "Frostbound Tundra":  ["Frost Crystal", "Ice Shard", "Frozen Herb", "Tundra Root"],
    "Crystal Spire":      ["Prism Dust", "Arcane Sliver", "Crystal Fragment", "Spark Moss"],
    "Sunken Coast":       ["Sea Salt", "Coral Dust", "Tide Pearl", "Storm Kelp"],
    "Ironpeak Mountains": ["Stone Dust", "Iron Ore", "Mountain Herb", "Boulder Moss"],
    "Blight Swamp":       ["Poison Ivy", "Rot Spore", "Swamp Mud", "Plague Petal"],
    "Shadow Vale":        ["Shadow Moss", "Void Sliver", "Dark Crystal", "Night Bloom"],
    "Riftlands":          ["Rift Dust", "Anomaly Shard", "Void Particle", "Phase Herb"],
    "Infernal Depths":    ["Hell Ash", "Brimstone", "Soul Ember", "Demon Fang"],
    "Celestial Expanse":  ["Stardust", "Sunstone", "Celestial Petal", "Astral Moss"],
    "Shattered Wastes":   ["Shard Dust", "Broken Crystal", "Fracture Ore", "Void Grit"],
    "The Dreamscape":     ["Dream Leaf", "Nightmare Spore", "Lucid Petal", "Sleep Dust"],
    "Abyss of Souls":     ["Soul Dust", "Abyss Stone", "Death Bloom", "Spirit Shard"],
    "Creator's Realm":    ["Divine Dust", "Creation Shard", "Origin Crystal"],
}

INGREDIENT_COMBOS = {
    # Healing
    frozenset(["Thorn Petal",     "Dew Blossom"]):     {"name": "Forest Salve",    "effect": "heal_40",        "desc": "Heals 40 HP"},
    frozenset(["Frost Crystal",   "Frozen Herb"]):     {"name": "Frost Tonic",     "effect": "heal_60",        "desc": "Heals 60 HP + cures freeze"},
    frozenset(["Stardust",        "Celestial Petal"]): {"name": "Celestial Draft", "effect": "heal_100",       "desc": "Heals 100 HP"},
    frozenset(["Sea Salt",        "Storm Kelp"]):      {"name": "Tidal Brew",      "effect": "heal_50",        "desc": "Heals 50 HP"},
    frozenset(["Mountain Herb",   "Boulder Moss"]):    {"name": "Stone Balm",      "effect": "heal_50",        "desc": "Heals 50 HP + cures bleed"},
    frozenset(["Dream Leaf",      "Lucid Petal"]):     {"name": "Dream Tonic",     "effect": "heal_80",        "desc": "Heals 80 HP + cures sleep/fear"},
    frozenset(["Vine Root",       "Forest Mushroom"]): {"name": "Root Brew",       "effect": "heal_30",        "desc": "Heals 30 HP"},
    frozenset(["Iron Ore",        "Mountain Herb"]):   {"name": "Iron Tonic",      "effect": "heal_40",        "desc": "Heals 40 HP"},
    frozenset(["Ash Dust",        "Scorched Bark"]):   {"name": "Ash Tonic",       "effect": "heal_20",        "desc": "Heals 20 HP"},
    frozenset(["Sunstone",        "Celestial Petal"]): {"name": "Solar Potion",    "effect": "heal_70_atk_10", "desc": "Heals 70 HP + +10 ATK for 2 fights"},
    frozenset(["Death Bloom",     "Abyss Stone"]):     {"name": "Death Draught",   "effect": "heal_80_cost10", "desc": "Heals 80 HP but costs 10 HP to drink"},
    frozenset(["Creation Shard",  "Origin Crystal"]): {"name": "Genesis Elixir",   "effect": "genesis",        "desc": "Fully restores HP and MP"},
    frozenset(["Coral Dust",      "Tide Pearl"]):      {"name": "Tide Surge",      "effect": "def_boost_15",   "desc": "+15 DEF for 3 fights"},
    frozenset(["Astral Moss",     "Stardust"]):        {"name": "Astral Balm",     "effect": "heal_60",        "desc": "Heals 60 HP"},
    # Cure
    frozenset(["Poison Ivy",      "Swamp Mud"]):       {"name": "Venom Cure",      "effect": "cure_status",    "desc": "Cures all status effects"},
    frozenset(["Plague Petal",    "Rot Spore"]):       {"name": "Plague Antidote", "effect": "cure_status",    "desc": "Cures poison, burn, bleed"},
    frozenset(["Shadow Moss",     "Night Bloom"]):     {"name": "Void Antidote",   "effect": "cure_void",      "desc": "Cures void and curse"},
    # ATK boost
    frozenset(["Ember Root",      "Cinder Shard"]):    {"name": "Ember Rage",      "effect": "atk_boost_15",   "desc": "+15 ATK for 3 fights"},
    frozenset(["Magma Crystal",   "Forge Cinder"]):    {"name": "Forge Draught",   "effect": "atk_boost_20",   "desc": "+20 ATK for 3 fights"},
    frozenset(["Demon Fang",      "Hell Ash"]):        {"name": "Infernal Rage",   "effect": "atk_boost_25",   "desc": "+25 ATK for 4 fights"},
    frozenset(["Rift Dust",       "Anomaly Shard"]):   {"name": "Rift Stimulant",  "effect": "atk_boost_20",   "desc": "+20 ATK for 3 fights"},
    frozenset(["Soul Ember",      "Brimstone"]):       {"name": "Soul Fury",       "effect": "atk_boost_20",   "desc": "+20 ATK for 3 fights"},
    frozenset(["Shard Dust",      "Fracture Ore"]):    {"name": "Shard Extract",   "effect": "atk_boost_10",   "desc": "+10 ATK for 3 fights"},
    frozenset(["Void Sliver",     "Dark Crystal"]):    {"name": "Void Draught",    "effect": "atk_boost_15",   "desc": "+15 ATK for 3 fights"},
    # DEF boost
    frozenset(["Stone Dust",      "Iron Ore"]):        {"name": "Iron Shell",      "effect": "def_boost_10",   "desc": "+10 DEF for 3 fights"},
    frozenset(["Prism Dust",      "Crystal Fragment"]):{  "name":"Crystal Ward",   "effect": "def_boost_15",   "desc": "+15 DEF for 3 fights"},
    frozenset(["Void Sliver",     "Shadow Moss"]):     {"name": "Shadow Shield",   "effect": "def_boost_12",   "desc": "+12 DEF for 3 fights"},
    frozenset(["Ice Shard",       "Frost Crystal"]):   {"name": "Frost Barrier",   "effect": "def_boost_12",   "desc": "+12 DEF + cures freeze"},
    # Luck / special
    frozenset(["Stardust",        "Sunstone"]):        {"name": "Star Luck",       "effect": "luck_boost",     "desc": "+25% loot quality for 5 explores"},
    frozenset(["Soul Dust",       "Spirit Shard"]):    {"name": "Soul Beacon",     "effect": "luck_boost",     "desc": "+25% loot quality for 5 explores"},
    frozenset(["Dream Leaf",      "Sleep Dust"]):      {"name": "Dream Vial",      "effect": "skip_fight",     "desc": "Next enemy falls asleep — skip one fight"},
    frozenset(["Arcane Sliver",   "Spark Moss"]):      {"name": "Arcane Surge",    "effect": "mana_full",      "desc": "Fully restores MP"},
    # Risky / wild
    frozenset(["Void Particle",   "Phase Herb"]):      {"name": "Phase Toxin",     "effect": "random_wild",    "desc": "Totally random — could be great or terrible"},
    frozenset(["Nightmare Spore", "Sleep Dust"]):      {"name": "Nightmare Brew",  "effect": "random_wild",    "desc": "Totally random — could be great or terrible"},
    frozenset(["Rot Spore",       "Swamp Mud"]):       {"name": "Rot Vial",        "effect": "random_bad",     "desc": "Probably awful — sell to a merchant"},
    frozenset(["Tundra Root",     "Ice Shard"]):       {"name": "Ice Brew",        "effect": "heal_35",        "desc": "Heals 35 HP"},
    frozenset(["Slag Chunk",      "Iron Dust"]):       {"name": "Slag Tonic",      "effect": "heal_25",        "desc": "Heals 25 HP"},
    frozenset(["Broken Crystal",  "Void Grit"]):       {"name": "Void Shard Brew", "effect": "atk_boost_10",   "desc": "+10 ATK for 2 fights"},
    frozenset(["Divine Dust",     "Creation Shard"]): {"name": "Divine Essence",   "effect": "genesis",        "desc": "Fully restores HP and MP"},
}

# =========================================================
# TOWER MONSTERS — per region, 3 floors (easy→hard)
# =========================================================

TOWER_MONSTERS = {
    "Ashen Wastes": [
        {"name": "Ember Scout",      "hp":  60, "atk": 22, "def":  5, "effect": "burn",   "xp": 24, "gold": 30},
        {"name": "Ash Warden",       "hp":  90, "atk": 28, "def":  7, "effect": "burn",   "xp": 38, "gold": 48},
        {"name": "Cinder Archon",    "hp": 130, "atk": 36, "def": 10, "effect": "magma",  "xp": 65, "gold": 90},
    ],
    "Crystal Spire": [
        {"name": "Prism Guard",      "hp":  70, "atk": 24, "def":  8, "effect": "freeze", "xp": 28, "gold": 36},
        {"name": "Spire Adept",      "hp": 100, "atk": 30, "def": 10, "effect": "shock",  "xp": 44, "gold": 58},
        {"name": "Crystal Archon",   "hp": 145, "atk": 38, "def": 14, "effect": "freeze", "xp": 72, "gold": 100},
    ],
    "Shadow Vale": [
        {"name": "Shade Initiate",   "hp":  75, "atk": 28, "def":  6, "effect": "void",   "xp": 30, "gold": 38},
        {"name": "Dark Warden",      "hp": 110, "atk": 36, "def":  9, "effect": "blind",  "xp": 48, "gold": 64},
        {"name": "Void Archon",      "hp": 155, "atk": 44, "def": 13, "effect": "void",   "xp": 80, "gold": 115},
    ],
    "Ironpeak Mountains": [
        {"name": "Iron Grunt",       "hp":  80, "atk": 22, "def": 12, "effect": "stun",   "xp": 32, "gold": 40},
        {"name": "Peak Sentinel",    "hp": 115, "atk": 30, "def": 16, "effect": "bleed",  "xp": 50, "gold": 68},
        {"name": "Mountain Archon",  "hp": 160, "atk": 40, "def": 20, "effect": "stun",   "xp": 84, "gold": 120},
    ],
    "Riftlands": [
        {"name": "Rift Seeker",      "hp":  85, "atk": 34, "def":  7, "effect": "shock",  "xp": 34, "gold": 44},
        {"name": "Anomaly Guard",    "hp": 120, "atk": 42, "def": 10, "effect": "void",   "xp": 55, "gold": 75},
        {"name": "Rift Archon",      "hp": 170, "atk": 52, "def": 14, "effect": "void",   "xp": 90, "gold": 135},
    ],
    "Shattered Wastes": [
        {"name": "Shard Watcher",    "hp":  80, "atk": 26, "def":  9, "effect": "bleed",  "xp": 32, "gold": 40},
        {"name": "Fracture Knight",  "hp": 115, "atk": 34, "def": 12, "effect": "stun",   "xp": 50, "gold": 68},
        {"name": "Shard Archon",     "hp": 155, "atk": 42, "def": 16, "effect": "bleed",  "xp": 82, "gold": 118},
    ],
    "Infernal Depths": [
        {"name": "Hell Grunt",       "hp":  80, "atk": 30, "def":  8, "effect": "burn",   "xp": 32, "gold": 42},
        {"name": "Flame Warden",     "hp": 118, "atk": 40, "def": 12, "effect": "magma",  "xp": 52, "gold": 72},
        {"name": "Infernal Archon",  "hp": 165, "atk": 52, "def": 17, "effect": "burn",   "xp": 88, "gold": 128},
    ],
    "Celestial Expanse": [
        {"name": "Astral Sentry",    "hp":  85, "atk": 30, "def": 18, "effect": "light",  "xp": 34, "gold": 44},
        {"name": "Star Warden",      "hp": 125, "atk": 40, "def": 24, "effect": "shock",  "xp": 56, "gold": 78},
        {"name": "Celestial Archon", "hp": 175, "atk": 52, "def": 30, "effect": "light",  "xp": 94, "gold": 140},
    ],
    "Blight Swamp": [
        {"name": "Swamp Lurker",     "hp":  68, "atk": 22, "def":  6, "effect": "poison", "xp": 27, "gold": 34},
        {"name": "Plague Knight",    "hp": 100, "atk": 30, "def":  9, "effect": "poison", "xp": 44, "gold": 60},
        {"name": "Blight Archon",    "hp": 145, "atk": 40, "def": 13, "effect": "poison", "xp": 75, "gold": 108},
    ],
}

# =========================================================
# DUNGEON MONSTERS — per region, 3 floors (easy→boss)
# =========================================================

DUNGEON_MONSTERS = {
    "Ashen Wastes": [
        {"name": "Catacombs Rat",     "hp":  50, "atk": 18, "def":  4, "effect": "burn",   "xp": 20, "gold": 25},
        {"name": "Ash Skeleton",      "hp":  78, "atk": 25, "def":  7, "effect": "burn",   "xp": 36, "gold": 48},
        {"name": "Catacombs Warden",  "hp": 125, "atk": 36, "def": 12, "effect": "magma",  "xp": 65, "gold": 90},
    ],
    "Crimson Depths": [
        {"name": "Vault Crawler",     "hp":  60, "atk": 20, "def":  6, "effect": "burn",   "xp": 25, "gold": 32},
        {"name": "Forge Specter",     "hp":  92, "atk": 28, "def": 10, "effect": "magma",  "xp": 44, "gold": 60},
        {"name": "Magma Colossus",    "hp": 145, "atk": 40, "def": 16, "effect": "magma",  "xp": 74, "gold": 108},
    ],
    "Frostbound Tundra": [
        {"name": "Frozen Revenant",   "hp":  55, "atk": 16, "def": 14, "effect": "freeze", "xp": 22, "gold": 28},
        {"name": "Glacier Shade",     "hp":  88, "atk": 22, "def": 20, "effect": "freeze", "xp": 40, "gold": 54},
        {"name": "Frost Lich",        "hp": 135, "atk": 34, "def": 26, "effect": "freeze", "xp": 70, "gold": 100},
    ],
    "Sunken Coast": [
        {"name": "Cave Eel",          "hp":  52, "atk": 22, "def":  9, "effect": "shock",  "xp": 21, "gold": 27},
        {"name": "Tidal Wraith",      "hp":  82, "atk": 30, "def": 14, "effect": "bleed",  "xp": 38, "gold": 50},
        {"name": "Cavern Kraken",     "hp": 138, "atk": 40, "def": 18, "effect": "shock",  "xp": 72, "gold": 104},
    ],
    "Blight Swamp": [
        {"name": "Swamp Crawler",     "hp":  55, "atk": 18, "def":  6, "effect": "poison", "xp": 22, "gold": 28},
        {"name": "Blight Shambler",   "hp":  88, "atk": 26, "def": 10, "effect": "poison", "xp": 40, "gold": 54},
        {"name": "Plague Overlord",   "hp": 135, "atk": 36, "def": 14, "effect": "poison", "xp": 70, "gold": 100},
    ],
    "Shadow Vale": [
        {"name": "Dark Servant",      "hp":  65, "atk": 26, "def":  7, "effect": "blind",  "xp": 28, "gold": 36},
        {"name": "Shadow Abomination","hp": 100, "atk": 36, "def": 12, "effect": "void",   "xp": 48, "gold": 66},
        {"name": "Void Sovereign",    "hp": 152, "atk": 48, "def": 17, "effect": "void",   "xp": 82, "gold": 120},
    ],
    "Infernal Depths": [
        {"name": "Dungeon Imp",       "hp":  65, "atk": 26, "def":  8, "effect": "burn",   "xp": 28, "gold": 36},
        {"name": "Hell Shade",        "hp": 100, "atk": 36, "def": 13, "effect": "magma",  "xp": 50, "gold": 68},
        {"name": "Infernal Tyrant",   "hp": 158, "atk": 48, "def": 19, "effect": "burn",   "xp": 85, "gold": 125},
    ],
    "Celestial Expanse": [
        {"name": "Fallen Seraph",     "hp":  70, "atk": 28, "def": 20, "effect": "light",  "xp": 30, "gold": 40},
        {"name": "Void Angel",        "hp": 108, "atk": 38, "def": 26, "effect": "shock",  "xp": 55, "gold": 75},
        {"name": "Cosmic Destroyer",  "hp": 168, "atk": 50, "def": 32, "effect": "void",   "xp": 92, "gold": 138},
    ],
    "Abyss of Souls": [
        {"name": "Soul Shard",        "hp":  80, "atk": 32, "def": 20, "effect": "void",   "xp": 35, "gold": 46},
        {"name": "Abyssal Specter",   "hp": 122, "atk": 44, "def": 30, "effect": "void",   "xp": 62, "gold": 86},
        {"name": "Abyss Sovereign",   "hp": 185, "atk": 60, "def": 40, "effect": "void",   "xp": 105,"gold": 158},
    ],
    "Riftlands": [
        {"name": "Phase Crawler",     "hp":  70, "atk": 30, "def":  7, "effect": "shock",  "xp": 30, "gold": 38},
        {"name": "Rift Specter",      "hp": 108, "atk": 40, "def": 12, "effect": "void",   "xp": 53, "gold": 72},
        {"name": "Source Devourer",   "hp": 165, "atk": 54, "def": 17, "effect": "void",   "xp": 88, "gold": 130},
    ],
    "Shattered Wastes": [
        {"name": "Shard Hatchling",   "hp":  65, "atk": 24, "def":  9, "effect": "bleed",  "xp": 27, "gold": 35},
        {"name": "Fracture Specter",  "hp": 102, "atk": 34, "def": 14, "effect": "stun",   "xp": 47, "gold": 64},
        {"name": "Prism Overlord",    "hp": 158, "atk": 46, "def": 20, "effect": "bleed",  "xp": 84, "gold": 122},
    ],
    "The Dreamscape": [
        {"name": "Dream Larva",       "hp":  62, "atk": 22, "def":  7, "effect": "sleep",  "xp": 26, "gold": 33},
        {"name": "Nightmare Shade",   "hp":  98, "atk": 32, "def": 12, "effect": "fear",   "xp": 44, "gold": 60},
        {"name": "Dream Vault Guardian","hp":148,"atk": 44, "def": 17, "effect": "void",   "xp": 78, "gold": 114},
    ],
    "Ironpeak Mountains": [
        {"name": "Mine Crawler",      "hp":  60, "atk": 20, "def": 10, "effect": "stun",   "xp": 24, "gold": 30},
        {"name": "Deep Golem",        "hp":  95, "atk": 28, "def": 16, "effect": "stun",   "xp": 42, "gold": 58},
        {"name": "Peak Warden",       "hp": 142, "atk": 38, "def": 22, "effect": "bleed",  "xp": 74, "gold": 106},
    ],
    "Crystal Spire": [
        {"name": "Prism Hatchling",   "hp":  58, "atk": 20, "def":  8, "effect": "freeze", "xp": 23, "gold": 30},
        {"name": "Arcane Specter",    "hp":  90, "atk": 28, "def": 12, "effect": "shock",  "xp": 40, "gold": 55},
        {"name": "Spire Overlord",    "hp": 138, "atk": 38, "def": 16, "effect": "freeze", "xp": 70, "gold": 100},
    ],
    "Whispering Woods": [
        {"name": "Root Horror",       "hp":  48, "atk": 14, "def":  5, "effect": "poison", "xp": 19, "gold": 24},
        {"name": "Corrupted Druid",   "hp":  75, "atk": 20, "def":  8, "effect": "root",   "xp": 34, "gold": 46},
        {"name": "Forest Sovereign",  "hp": 118, "atk": 30, "def": 12, "effect": "poison", "xp": 62, "gold": 88},
    ],
    "Frostbound Tundra": [
        {"name": "Frozen Revenant",   "hp":  55, "atk": 16, "def": 14, "effect": "freeze", "xp": 22, "gold": 28},
        {"name": "Glacier Shade",     "hp":  88, "atk": 22, "def": 20, "effect": "freeze", "xp": 40, "gold": 54},
        {"name": "Frost Lich",        "hp": 135, "atk": 34, "def": 26, "effect": "freeze", "xp": 70, "gold": 100},
    ],
}

# =========================================================
# NEW STRUCTURE TYPES
# =========================================================

EXTRA_STRUCTURES = {
    "Whispering Woods":   [{"name": "Druid Library",   "type": "library",     "icon": "📚"},
                           {"name": "Bandit Camp",     "type": "camp",        "icon": "⛺"}],
    "Ashen Wastes":       [{"name": "Scorched Arena",  "type": "arena",       "icon": "⚔"},
                           {"name": "Ash Graveyard",   "type": "graveyard",   "icon": "🪦"}],
    "Crimson Depths":      [{"name": "Forge Blacksmith","type": "blacksmith",  "icon": "🔨"},
                           {"name": "Lava Cave",       "type": "cave",        "icon": "🪨"}],
    "Frostbound Tundra":  [{"name": "Frost Library",   "type": "library",     "icon": "📚"},
                           {"name": "Ice Cave",        "type": "cave",        "icon": "🪨"}],
    "Crystal Spire":      [{"name": "Arcane Arena",    "type": "arena",       "icon": "⚔"},
                           {"name": "Crystal Blacksmith","type":"blacksmith",  "icon": "🔨"}],
    "Sunken Coast":       [{"name": "Sea Cave",        "type": "cave",        "icon": "🪨"},
                           {"name": "Reef Graveyard",  "type": "graveyard",   "icon": "🪦"}],
    "Ironpeak Mountains": [{"name": "Mountain Blacksmith","type":"blacksmith", "icon": "🔨"},
                           {"name": "Mine Cave",       "type": "cave",        "icon": "🪨"}],
    "Blight Swamp":       [{"name": "Swamp Camp",      "type": "camp",        "icon": "⛺"},
                           {"name": "Plague Graveyard","type": "graveyard",   "icon": "🪦"}],
    "Shadow Vale":        [{"name": "Shadow Arena",    "type": "arena",       "icon": "⚔"},
                           {"name": "Void Graveyard",  "type": "graveyard",   "icon": "🪦"}],
    "Infernal Depths":    [{"name": "Hell Arena",      "type": "arena",       "icon": "⚔"},
                           {"name": "Brimstone Cave",  "type": "cave",        "icon": "🪨"}],
    "Celestial Expanse":  [{"name": "Astral Library",  "type": "library",     "icon": "📚"},
                           {"name": "Celestial Blacksmith","type":"blacksmith","icon": "🔨"}],
    "Riftlands":          [{"name": "Rift Arena",      "type": "arena",       "icon": "⚔"},
                           {"name": "Phase Camp",      "type": "camp",        "icon": "⛺"}],
    "Abyss of Souls":     [{"name": "Abyss Graveyard", "type": "graveyard",   "icon": "🪦"},
                           {"name": "Soul Arena",      "type": "arena",       "icon": "⚔"}],
    "Shattered Wastes":   [{"name": "Shard Cave",      "type": "cave",        "icon": "🪨"},
                           {"name": "Fracture Library","type": "library",     "icon": "📚"}],
    "The Dreamscape":     [{"name": "Dream Library",   "type": "library",     "icon": "📚"},
                           {"name": "Nightmare Camp",  "type": "camp",        "icon": "⛺"}],
    "Creator's Realm":    [{"name": "Creator's Arena", "type": "arena",       "icon": "⚔"}],
}

# Merge EXTRA_STRUCTURES into REGION_STRUCTURES
for _r, _extras in EXTRA_STRUCTURES.items():
    if _r in REGION_STRUCTURES:
        REGION_STRUCTURES[_r].extend(_extras)

# =========================================================
# LIBRARY TOMES — readable in library structures
# =========================================================

LIBRARY_TOMES = [
    {"title": "The Art of Survival",    "effect": "max_hp_10",  "desc": "Your max HP increases by 10."},
    {"title": "Shadowstep Teachings",   "effect": "def_perm_3", "desc": "Your defence permanently rises by 3."},
    {"title": "The Forge Codex",        "effect": "atk_perm_3", "desc": "Your attack permanently rises by 3."},
    {"title": "Lore of the Abyss",      "effect": "xp_boost",   "desc": "You gain 80 XP from the ancient wisdom."},
    {"title": "Merchant's Handbook",    "effect": "gold_80",    "desc": "A hidden map leads you to 80 buried souls."},
    {"title": "Tome of Resilience",     "effect": "max_hp_15",  "desc": "Your max HP increases by 15."},
    {"title": "The Wanderer's Path",    "effect": "hunger_full", "desc": "You feel nourished — hunger restored to full."},
    {"title": "Secrets of the Void",    "effect": "mana_full",  "desc": "Your mana is fully restored."},
    {"title": "Bestiary of the Depths", "effect": "xp_boost",   "desc": "Knowledge of enemies grants you 120 XP."},
    {"title": "Alchemist's Notes",      "effect": "ingredient", "desc": "You discover a rare ingredient tucked inside the pages."},
]

# =========================================================
# GRAVEYARD LOOT — risky digging
# =========================================================

GRAVEYARD_LOOT = [
    {"name": "Grave Gold",    "value": 60,  "type": "gold",      "desc": "A pouch of souls buried with the dead."},
    {"name": "Bone Charm",    "value": 40,  "type": "gold",      "desc": "A cursed trinket. Worth souls to a collector."},
    {"name": "Old Weapon",    "value": 0,   "type": "weapon",    "desc": "A rusted weapon from a fallen warrior."},
    {"name": "Burial Armour", "value": 0,   "type": "armour",    "desc": "Cracked armour stripped from a corpse."},
    {"name": "Death Bloom",   "value": 0,   "type": "ingredient","desc": "A rare ingredient that only grows near death."},
    {"name": "Spirit Shard",  "value": 0,   "type": "ingredient","desc": "Crystallised soul energy. Useful for brewing."},
    {"name": "Grave Curse",   "value": 0,   "type": "curse",     "desc": "You disturbed the dead. You are cursed."},
    {"name": "Nothing",       "value": 0,   "type": "empty",     "desc": "Just dirt and bones. Nothing of value."},
]


WEAPONS.extend([
    {"name": "Voidfang Scimitar",    "tier": "mid",   "atk": 15, "element": "void",    "effect": "void",    "cores": {}},
    {"name": "Plague Scythe",        "tier": "mid",   "atk": 13, "element": "poison",  "effect": "poison",  "cores": {}},
    {"name": "Stormcaller Spear",    "tier": "mid",   "atk": 14, "element": "shock",   "effect": "shock",   "cores": {}},
    {"name": "Nightmare Glaive",     "tier": "rare",  "atk": 20, "element": "shadow",  "effect": "fear",    "cores": {}},
    {"name": "Frostbite Axe",        "tier": "rare",  "atk": 18, "element": "ice",     "effect": "freeze",  "cores": {}},
    {"name": "Soulrender Blade",     "tier": "rare",  "atk": 22, "element": "soul",    "effect": "necrosis","cores": {}},
    {"name": "Titan's Fist",         "tier": "epic",  "atk": 28, "element": "titan",   "effect": "stun",    "cores": {}},
    {"name": "Celestial Archblade",  "tier": "epic",  "atk": 32, "element": "celestial","effect": "light",  "cores": {}},
])


LOOT_ITEMS.extend([
    {"name": "Whispering Skull",     "value": 45},
    {"name": "Void Crystal",         "value": 85},
    {"name": "Shattered Halo",       "value": 130},
    {"name": "Demon's Eye",          "value": 160},
    {"name": "Primordial Shard",     "value": 250},
])


MERCHANT_ITEMS["Whispering Woods"].extend(["Plague Scythe", "Voidfang Scimitar"])
MERCHANT_ITEMS["Infernal Depths"].extend(["Soulrender Blade", "Nightmare Glaive"])


STAFFS.extend([
    {"name": "Plague Sceptre",       "element": "venom",  "power": 20},
    {"name": "Stormrider Staff",     "element": "storm",  "power": 23},
    {"name": "Soulweaver Rod",       "element": "soul",   "power": 27},
])


_NEW_WANDERERS = {
    "Whispering Woods":   {"name": "Thornmaw Beast",     "hp":  88, "atk": 22, "def":  9, "effect": "root",   "xp": 38, "gold": 50},
    "Ashen Wastes":       {"name": "Cinder Fiend",       "hp":  95, "atk": 28, "def":  8, "effect": "burn",   "xp": 42, "gold": 55},
    "Crimson Depths":      {"name": "Molten Hulk",        "hp": 100, "atk": 30, "def": 12, "effect": "magma",  "xp": 46, "gold": 60},
    "Frostbound Tundra":  {"name": "Ice Specter",        "hp":  90, "atk": 24, "def": 18, "effect": "freeze", "xp": 40, "gold": 52},
    "Crystal Spire":      {"name": "Prism Crawler",      "hp":  85, "atk": 26, "def": 11, "effect": "shock",  "xp": 38, "gold": 50},
    "Sunken Coast":       {"name": "Tidal Serpent",      "hp":  92, "atk": 28, "def": 12, "effect": "bleed",  "xp": 42, "gold": 56},
    "Ironpeak Mountains": {"name": "Stone Golem",        "hp": 105, "atk": 24, "def": 20, "effect": "stun",   "xp": 44, "gold": 58},
    "Blight Swamp":       {"name": "Bog Wraith",         "hp":  88, "atk": 26, "def":  8, "effect": "poison", "xp": 40, "gold": 52},
    "Shadow Vale":        {"name": "Void Lurker",        "hp":  95, "atk": 32, "def": 10, "effect": "blind",  "xp": 44, "gold": 58},
    "Riftlands":          {"name": "Phase Phantom",      "hp":  98, "atk": 36, "def":  9, "effect": "void",   "xp": 46, "gold": 62},
    "Infernal Depths":    {"name": "Brimstone Demon",    "hp": 102, "atk": 34, "def": 12, "effect": "burn",   "xp": 48, "gold": 64},
    "Celestial Expanse":  {"name": "Fallen Cherub",      "hp":  95, "atk": 32, "def": 22, "effect": "light",  "xp": 46, "gold": 62},
    "Shattered Wastes":   {"name": "Shard Colossus",     "hp": 108, "atk": 30, "def": 14, "effect": "bleed",  "xp": 48, "gold": 64},
    "The Dreamscape":     {"name": "Lucid Horror",       "hp":  90, "atk": 30, "def": 10, "effect": "sleep",  "xp": 42, "gold": 56},
    "Abyss of Souls":     {"name": "Soul Eater",         "hp": 110, "atk": 38, "def": 24, "effect": "void",   "xp": 55, "gold": 75},
}
for _r, _mob in _NEW_WANDERERS.items():
    if _r in DUNGEON_MONSTERS:
        DUNGEON_MONSTERS[_r].insert(1, _mob)

# ── 1 new structure per region (shrine) ───────────────────
_NEW_SHRINES = {r: [{"name": f"{r.split()[0]} Shrine", "type": "shrine", "icon": "⛩"}]
                for r in REGION_STRUCTURES}
for _r, _ss in _NEW_SHRINES.items():
    REGION_STRUCTURES[_r].extend(_ss)
METALS = {
    "Iron": {"atk": 5, "effect": "none"},
    "Steel": {"atk": 10, "effect": "armor_break"},
    "Crimson Steel": {"atk": 15, "effect": "burn"},
    "Froststeel": {"atk": 14, "effect": "freeze"},
    "Void Alloy": {"atk": 18, "effect": "void"},
    "Titanium": {"atk": 16, "effect": "stun"},
    "Soulsteel": {"atk": 20, "effect": "life_drain"},
    "Starmetal": {"atk": 22, "effect": "starfall"},
    "Dragonsteel": {"atk": 24, "effect": "dragon_fury"},
    "Phoenix Iron": {"atk": 23, "effect": "rebirth"},
    "Shadow Iron": {"atk": 19, "effect": "fear"},
    "Lightsteel": {"atk": 19, "effect": "heal_tick"},
    "Abyssium": {"atk": 26, "effect": "curse"},
    "Stormsteel": {"atk": 21, "effect": "shock"},
    "Crystal Alloy": {"atk": 20, "effect": "crit_up"},
    "Infernium": {"atk": 28, "effect": "hellfire"},
    "Celestium": {"atk": 27, "effect": "divine_luck"},
    "Riftsteel": {"atk": 25, "effect": "dimension_break"},
    "Chronosteel": {"atk": 24, "effect": "slow_time"},
    "Creator Alloy": {"atk": 35, "effect": "creation"},
}
CLOTHS = {
    "Linen": {"tier": "basic", "def": 2, "spd": 1},
    "Wool": {"tier": "basic", "def": 3, "spd": 0},
    "Silk": {"tier": "rare", "def": 3, "spd": 3},
    "Crimson Silk": {"tier": "rare", "def": 4, "spd": 2},
    "Dragon Silk": {"tier": "legendary", "def": 5, "spd": 5},
    "Starweave": {"tier": "epic", "def": 4, "spd": 4},
    "Shadowcloth": {"tier": "rare", "def": 3, "spd": 4},
    "Celestial Weave": {"tier": "legendary", "def": 6, "spd": 3},
}

LEATHERS = {
    "Tanned Hide": {"tier": "basic", "def": 4},
    "Cured Leather": {"tier": "mid", "def": 6},
    "Dragon Hide": {"tier": "rare", "def": 8},
    "Shadow Leather": {"tier": "rare", "def": 7},
    "Phoenix Leather": {"tier": "epic", "def": 9},
    "Abyssal Leather": {"tier": "legendary", "def": 10},
}

WOODS = {
    "Oak": {"hp": 5},
    "Ashwood": {"crit": 5},
    "Emberwood": {"burn_bonus": 2},
    "Shadowwood": {"crit": 10},
    "Soulwood": {"lifesteal": 3},
    "Ironbark": {"def": 3},
    "Frostwood": {"freeze_bonus": 2},
    "Stormwood": {"shock_bonus": 2},
    "Dreamwood": {"mana": 5},
    "Voidwood": {"curse_bonus": 2},
    "Phoenixwood": {"rebirth_bonus": 1},
    "Dragonwood": {"atk": 5},
    "Moonwood": {"heal": 5},
    "Sunwood": {"light_bonus": 2},
    "Crystalwood": {"crit": 8},
    "Ancient Bark": {"hp": 15},
    "Worldwood": {"all_stats": 3},
    "Riftwood": {"speed": 5},
    "Titanwood": {"def": 5},
    "Mythroot": {"atk": 10},
}
CORES = {
    "Molten Core": {"prefix": "Infernal", "effect": "burn"},
    "Nature Core": {"prefix": "Verdant", "effect": "root"},
    "Glacier Core": {"prefix": "Frozen", "effect": "freeze"},
    "Soul Core": {"prefix": "Soulreaper", "effect": "life_drain"},
    "Shadow Core": {"prefix": "Nightfall", "effect": "fear"},
    "Star Core": {"prefix": "Astral", "effect": "starfall"},
    "Ocean Core": {"prefix": "Tidal", "effect": "soak"},
    "Iron Core": {"prefix": "Titan", "effect": "stun"},
    "Blight Core": {"prefix": "Plague", "effect": "poison"},
    "Anomaly Core": {"prefix": "Riftborn", "effect": "dimension_break"},
    "Hellfire Core": {"prefix": "Demonic", "effect": "hellfire"},
    "Lucid Core": {"prefix": "Dreamforged", "effect": "sleep"},
    "Spire Core": {"prefix": "Crystal", "effect": "crit_up"},
    "Ember Core": {"prefix": "Ashen", "effect": "burn"},
    "Prism Core": {"prefix": "Prismatic", "effect": "random_effect"},
    "Celestial Core": {"prefix": "Divine", "effect": "heal_tick"},
    "Abyss Core": {"prefix": "Abyssal", "effect": "curse"},
    "Dragon Core": {"prefix": "Draconic", "effect": "dragon_fury"},
    "Phoenix Core": {"prefix": "Phoenix", "effect": "rebirth"},
    "Omnipotent Core": {"prefix": "Creator's", "effect": "creation"},
}

# =========================================================
# CRAFTING STRUCTURES
# =========================================================

STRUCTURES = {
    "forge": {
        "name": "Forge",
        "level": 1,
        "icon": "🔨",
        "description": "Craft and upgrade weapons",
        "upgrade_cost": 500,
        "crafting_bonus": 0.05,
        "location": "Crimson Depths",
        "restricts_to": ["weapons"],
    },
    "loom": {
        "name": "Loom",
        "level": 1,
        "icon": "🧵",
        "description": "Craft cloth armor pieces",
        "upgrade_cost": 300,
        "crafting_bonus": 0.05,
        "location": "Elemental Villages",
        "restricts_to": ["armor"],
    },
    "enchantment_tower": {
        "name": "Enchantment Tower",
        "level": 1,
        "icon": "✨",
        "description": "Combine runes to create staffs",
        "upgrade_cost": 800,
        "crafting_bonus": 0.05,
        "location": "Crimson Depths",
        "restricts_to": ["staffs"],
    },
    "alchemy_lab": {
        "name": "Alchemy Lab",
        "level": 1,
        "icon": "🧪",
        "description": "Create potions and brews",
        "upgrade_cost": 400,
        "crafting_bonus": 0.05,
        "location": "Elemental Villages",
        "restricts_to": ["potions"],
    },
    "disenchantry": {
        "name": "Disenchantry",
        "level": 1,
        "icon": "💀",
        "description": "Disenchant items for materials",
        "upgrade_cost": 600,
        "crafting_bonus": 0.05,
        "location": "Anywhere",
        "restricts_to": ["salvage"],
    },
    "source_temple": {
        "name": "Source Temple",
        "level": 1,
        "icon": "🏛️",
        "description": "Imbue staffs with rune energy",
        "upgrade_cost": 1000,
        "crafting_bonus": 0.1,
        "location": "Source Temple",
        "restricts_to": ["imbue"],
    },
}



# =========================================================
# ARMOR CRAFTING RECIPES - Modular Pieces
# =========================================================

ARMOR_RECIPES = {
    "helmet": [
        {
            "name": "Linen Cap",
            "materials": {"Linen": 2},
            "def": 2,
            "hp": 5,
            "spd": 1,
            "tier": "basic",
            "cost": 50,
        },
        {
            "name": "Iron Helm",
            "materials": {"Iron": 2, "Linen": 1},
            "def": 5,
            "hp": 8,
            "spd": 0,
            "tier": "basic",
            "cost": 100,
        },
        {
            "name": "Steel-Silk Crown",
            "materials": {"Steel": 2, "Silk": 1},
            "def": 8,
            "hp": 12,
            "spd": 2,
            "tier": "mid",
            "cost": 250,
        },
        {
            "name": "Dragon-Hide Circlet",
            "materials": {"Dragon Hide": 1, "Silk": 2},
            "def": 10,
            "hp": 15,
            "spd": 3,
            "tier": "rare",
            "cost": 500,
        },
    ],
    "chest": [
        {
            "name": "Linen Tunic",
            "materials": {"Linen": 3},
            "def": 3,
            "hp": 10,
            "spd": 0,
            "tier": "basic",
            "cost": 75,
        },
        {
            "name": "Iron Plate",
            "materials": {"Iron": 4, "Linen": 1},
            "def": 12,
            "hp": 20,
            "spd": -1,
            "tier": "basic",
            "cost": 150,
        },
        {
            "name": "Steel-Silk Chestplate",
            "materials": {"Steel": 3, "Silk": 2},
            "def": 15,
            "hp": 30,
            "spd": 1,
            "tier": "mid",
            "cost": 400,
        },
        {
            "name": "Dragon-Hide Armor",
            "materials": {"Dragon Hide": 2, "Starweave": 2},
            "def": 18,
            "hp": 45,
            "spd": 2,
            "tier": "rare",
            "cost": 750,
        },
    ],
    "legs": [
        {
            "name": "Linen Leggings",
            "materials": {"Linen": 2},
            "def": 2,
            "hp": 8,
            "spd": 1,
            "tier": "basic",
            "cost": 50,
        },
        {
            "name": "Steel Leggings",
            "materials": {"Steel": 2, "Linen": 1},
            "def": 8,
            "hp": 15,
            "spd": 0,
            "tier": "basic",
            "cost": 100,
        },
        {
            "name": "Silk Trousers",
            "materials": {"Silk": 3},
            "def": 5,
            "hp": 12,
            "spd": 3,
            "tier": "mid",
            "cost": 200,
        },
        {
            "name": "Dragon-Hide Skirt",
            "materials": {"Dragon Hide": 1, "Dragon Silk": 1},
            "def": 12,
            "hp": 30,
            "spd": 4,
            "tier": "rare",
            "cost": 600,
        },
    ],
    "feet": [
        {
            "name": "Linen Boots",
            "materials": {"Linen": 1},
            "def": 1,
            "hp": 3,
            "spd": 1,
            "tier": "basic",
            "cost": 30,
        },
        {
            "name": "Steel Boots",
            "materials": {"Steel": 1, "Linen": 1},
            "def": 4,
            "hp": 6,
            "spd": 0,
            "tier": "basic",
            "cost": 75,
        },
        {
            "name": "Silk Slippers",
            "materials": {"Silk": 2},
            "def": 3,
            "hp": 5,
            "spd": 3,
            "tier": "mid",
            "cost": 150,
        },
        {
            "name": "Dragon-Hide Greaves",
            "materials": {"Dragon Hide": 1, "Starweave": 1},
            "def": 7,
            "hp": 12,
            "spd": 3,
            "tier": "rare",
            "cost": 400,
        },
    ],
}

# =========================================================
# STAFF CRAFTING COMBINATIONS - Rune Fusion Recipes
# =========================================================

STAFF_RECIPES = {
    # 2-rune combos
    "2_runes": [
        {
            "runes": ["fire_rune", "fire_rune"],
            "name": "Inferno Staff",
            "power_multiplier": 1.2,
            "atk_bonus": 8,
            "description": "Double-reinforced flames",
        },
        {
            "runes": ["fire_rune", "lifesteal_rune"],
            "name": "Siphoning Flame",
            "power_multiplier": 1.1,
            "atk_bonus": 6,
            "description": "Fire and vitality combined",
        },
        {
            "runes": ["ice_rune", "ice_rune"],
            "name": "Frostbringer Staff",
            "power_multiplier": 1.2,
            "def_bonus": 6,
            "description": "Twin frozen hearts",
        },
        {
            "runes": ["lightning_rune", "lightning_rune"],
            "name": "Stormcaller Staff",
            "power_multiplier": 1.2,
            "atk_bonus": 10,
            "description": "Lightning strikes twice",
        },
        {
            "runes": ["holy_rune", "reflect_rune"],
            "name": "Guardian's Staff",
            "power_multiplier": 1.15,
            "def_bonus": 8,
            "description": "Divine protection",
        },
    ],
    # 3-rune combos
    "3_runes": [
        {
            "runes": ["fire_rune", "fire_rune", "fire_rune"],
            "name": "Infernal Wrath",
            "power_multiplier": 1.35,
            "atk_bonus": 12,
            "description": "Tripled flames",
        },
        {
            "runes": ["fire_rune", "lifesteal_rune", "lifesteal_rune"],
            "name": "Eternal Hunger",
            "power_multiplier": 1.25,
            "atk_bonus": 8,
            "description": "Never-ending drain",
        },
        {
            "runes": ["ice_rune", "ice_rune", "wind_rune"],
            "name": "Blizzard Staff",
            "power_multiplier": 1.3,
            "def_bonus": 4,
            "description": "Frozen tempest",
        },
        {
            "runes": ["holy_rune", "holy_rune", "reflect_rune"],
            "name": "Divine Sanctuary",
            "power_multiplier": 1.3,
            "def_bonus": 10,
            "description": "Sacred defense",
        },
        {
            "runes": ["lightning_rune", "lightning_rune", "iron_rune"],
            "name": "Thunderknight Staff",
            "power_multiplier": 1.28,
            "atk_bonus": 8,
            "description": "Storm and strength",
        },
    ],
    # 4-rune combos
    "4_runes": [
        {
            "runes": ["fire_rune", "fire_rune", "fire_rune", "fire_rune"],
            "name": "Eternal Inferno",
            "power_multiplier": 1.5,
            "atk_bonus": 15,
            "description": "Apocalyptic flame",
        },
        {
            "runes": ["holy_rune", "holy_rune", "reflect_rune", "reflect_rune"],
            "name": "Aegis Prime",
            "power_multiplier": 1.45,
            "def_bonus": 15,
            "description": "Impenetrable shield",
        },
        {
            "runes": ["void_rune", "abyss_rune", "poison_rune", "lightning_rune"],
            "name": "Chaos Catalyst",
            "power_multiplier": 1.4,
            "atk_bonus": 12,
            "description": "Elemental chaos",
        },
    ],
    # 5-rune combo (ultimate)
    "5_runes": [
        {
            "runes": ["fire_rune", "ice_rune", "lightning_rune", "holy_rune", "void_rune"],
            "name": "Primal Nexus",
            "power_multiplier": 1.7,
            "atk_bonus": 18,
            "def_bonus": 10,
            "description": "All elements converge",
        },
    ],
}

# =========================================================
# EQUIPMENT SETS - Bonuses for Matching Sets
# =========================================================

EQUIPMENT_SETS = {
    "Crimson Knight": {
        "pieces": ["Crimson Pike", "Crimson Dagger", "Crimson Axe"],
        "bonuses": {
            2: {"atk": 5, "def": 5},
            3: {"atk": 10, "def": 10, "lifesteal": 0.1},
        },
    },
    "Frost Sage": {
        "pieces": ["Frostbite Axe", "Frostbringer Staff"],
        "bonuses": {
            2: {"def": 8, "atk": -2},
        },
    },
    "Lightning Warrior": {
        "pieces": ["Stormcaller Spear", "Stormcaller Staff"],
        "bonuses": {
            2: {"atk": 10, "spd": 5},
        },
    },
}

# =========================================================
# DAILY & WEEKLY CHALLENGES SYSTEM
# =========================================================

DAILY_CHALLENGES = [
    {
        "id": "daily_1",
        "name": "Monster Hunter",
        "description": "Defeat 10 monsters",
        "target": 10,
        "reward_gold": 100,
        "reward_materials": {"metal_scraps": 3},
        "type": "kill_count"
    },
    {
        "id": "daily_2",
        "name": "Treasure Collector",
        "description": "Collect 5 loot items",
        "target": 5,
        "reward_gold": 75,
        "reward_materials": {"cloth_scraps": 2},
        "type": "item_collect"
    },
    {
        "id": "daily_3",
        "name": "XP Grinder",
        "description": "Gain 200 XP",
        "target": 200,
        "reward_gold": 80,
        "reward_materials": {"essence_dust": 1},
        "type": "xp_gain"
    },
    {
        "id": "daily_4",
        "name": "Boss Slayer",
        "description": "Defeat 2 bosses",
        "target": 2,
        "reward_gold": 150,
        "reward_materials": {"rare_core": 1},
        "type": "boss_kill"
    },
    {
        "id": "daily_5",
        "name": "Crafter's Work",
        "description": "Craft 3 items",
        "target": 3,
        "reward_gold": 120,
        "reward_materials": {"crafting_shard": 2},
        "type": "craft_count"
    }
]

WEEKLY_CHALLENGES = [
    {
        "id": "weekly_1",
        "name": "Region Conqueror",
        "description": "Defeat bosses in 3 different regions",
        "target": 3,
        "reward_gold": 500,
        "reward_materials": {"legendary_core": 1},
        "type": "region_boss_clear"
    },
    {
        "id": "weekly_2",
        "name": "Material Master",
        "description": "Collect 50 raw materials",
        "target": 50,
        "reward_gold": 400,
        "reward_materials": {"premium_cloth": 5},
        "type": "material_collect"
    },
    {
        "id": "weekly_3",
        "name": "Prestige Progress",
        "description": "Reach level 5",
        "target": 5,
        "reward_gold": 600,
        "reward_materials": {"prestige_shard": 3},
        "type": "level_reach"
    },
    {
        "id": "weekly_4",
        "name": "Combat Expert",
        "description": "Defeat 30 monsters",
        "target": 30,
        "reward_gold": 450,
        "reward_materials": {"warrior_token": 1},
        "type": "kill_count"
    }
]

# =========================================================
# BOSS RUSHING MODE - Arcade-Style Boss Battles
# =========================================================

BOSS_RUSH_CONFIGURATIONS = {
    "normal": {
        "name": "Normal Rush",
        "bosses_count": 5,
        "difficulty_multiplier": 1.0,
        "reward_multiplier": 1.0,
        "description": "Face 5 bosses in rapid succession"
    },
    "hard": {
        "name": "Hard Rush",
        "bosses_count": 8,
        "difficulty_multiplier": 1.3,
        "reward_multiplier": 1.5,
        "description": "Face 8 bosses with 30% increased difficulty"
    },
    "nightmare": {
        "name": "Nightmare Rush",
        "bosses_count": 10,
        "difficulty_multiplier": 1.8,
        "reward_multiplier": 2.5,
        "description": "Face 10 bosses with 80% increased difficulty"
    }
}

# =========================================================
# SKILL TREES - 3 BUILD TYPES WITH PERMANENT BONUSES
# =========================================================

SKILL_TREES = {
    "warrior": {
        "name": "Warrior",
        "icon": "⚔",
        "description": "Master of weapons and defense",
        "skills": {
            "heavy_strike": {"cost": 1, "stat": "atk", "bonus": 2, "level": 1},
            "iron_skin": {"cost": 1, "stat": "def", "bonus": 2, "level": 1},
            "battle_cry": {"cost": 2, "stat": "atk", "bonus": 4, "level": 2},
            "shield_wall": {"cost": 2, "stat": "def", "bonus": 4, "level": 2},
            "berserker_rage": {"cost": 3, "stat": "atk", "bonus": 8, "level": 3},
            "final_stand": {"cost": 3, "stat": "hp", "bonus": 20, "level": 3}
        }
    },
    "mage": {
        "name": "Mage",
        "icon": "✨",
        "description": "Master of magic and mana",
        "skills": {
            "arcane_bolt": {"cost": 1, "stat": "atk", "bonus": 2, "level": 1},
            "mana_shield": {"cost": 1, "stat": "mana", "bonus": 5, "level": 1},
            "spell_mastery": {"cost": 2, "stat": "atk", "bonus": 3, "level": 2},
            "mana_pool": {"cost": 2, "stat": "mana", "bonus": 10, "level": 2},
            "spell_amplify": {"cost": 3, "stat": "atk", "bonus": 6, "level": 3},
            "infinite_mana": {"cost": 3, "stat": "mana", "bonus": 20, "level": 3}
        }
    },
    "rogue": {
        "name": "Rogue",
        "icon": "🗡",
        "description": "Master of speed and precision",
        "skills": {
            "quick_strike": {"cost": 1, "stat": "spd", "bonus": 2, "level": 1},
            "evasion": {"cost": 1, "stat": "def", "bonus": 1, "level": 1},
            "swift_blade": {"cost": 2, "stat": "spd", "bonus": 3, "level": 2},
            "dodge_master": {"cost": 2, "stat": "def", "bonus": 2, "level": 2},
            "shadow_clone": {"cost": 3, "stat": "spd", "bonus": 5, "level": 3},
            "deadly_precision": {"cost": 3, "stat": "atk", "bonus": 6, "level": 3}
        }
    }
}

# =========================================================
# COSMETICS SHOP - CHARACTER SKINS & CUSTOMIZATION
# =========================================================

COSMETICS_SHOP = {
    "character_skins": {
        "default": {"name": "Default", "price": 0},
        "dark_knight": {"name": "Dark Knight", "price": 100},
        "celestial_sage": {"name": "Celestial Sage", "price": 150},
        "void_walker": {"name": "Void Walker", "price": 200},
        "shadow_assassin": {"name": "Shadow Assassin", "price": 150},
        "legendary_hero": {"name": "Legendary Hero", "price": 300}
    },
    "weapon_skins": {
        "default": {"name": "Default", "price": 0},
        "flame_edge": {"name": "Flame Edge", "price": 75},
        "frost_blade": {"name": "Frost Blade", "price": 75},
        "eclipse_sword": {"name": "Eclipse Sword", "price": 150},
        "void_cleaver": {"name": "Void Cleaver", "price": 200}
    },
    "titles": {
        "Novice": {"name": "Novice", "price": 0},
        "Adventurer": {"name": "Adventurer", "price": 50},
        "Champion": {"name": "Champion", "price": 100},
        "Legend": {"name": "Legend", "price": 200},
        "Mythical": {"name": "Mythical", "price": 300},
        "Eternal": {"name": "Eternal", "price": 500}
    }
}

# =========================================================
# GUILD SYSTEM - CLANS WITH SHARED BENEFITS
# =========================================================

GUILD_RANKS = ["Member", "Officer", "Leader"]
GUILD_BONUSES = {
    "level_1": {"gold": 0.05, "materials": 0.05, "xp": 0.05},
    "level_2": {"gold": 0.10, "materials": 0.10, "xp": 0.10},
    "level_3": {"gold": 0.15, "materials": 0.15, "xp": 0.15},
    "level_4": {"gold": 0.20, "materials": 0.20, "xp": 0.20},
    "level_5": {"gold": 0.25, "materials": 0.25, "xp": 0.25}
}

# =========================================================
# SEASONAL EVENTS - TIME-LIMITED CONTENT
# =========================================================

SEASONAL_EVENTS = {
    "fire_festival": {
        "name": "Fire Festival",
        "duration": 30,
        "icon": "🔥",
        "unique_bosses": ["Infernal Phoenix", "Magma Lord"],
        "unique_materials": ["festival_ember", "phoenix_feather"],
        "exclusive_cosmetics": ["flame_warrior", "phoenix_crown"]
    },
    "frost_awakening": {
        "name": "Frost Awakening",
        "duration": 30,
        "icon": "❄",
        "unique_bosses": ["Glacial Titan", "Eternal Blizzard"],
        "unique_materials": ["frost_crystal", "ice_shard"],
        "exclusive_cosmetics": ["frost_sage", "winter_crown"]
    },
    "void_incursion": {
        "name": "Void Incursion",
        "duration": 30,
        "icon": "🌑",
        "unique_bosses": ["Void Sovereign", "Abyss Guardian"],
        "unique_materials": ["void_essence", "dark_matter"],
        "exclusive_cosmetics": ["void_walker", "abyss_crown"]
    }
}

# =========================================================
# SPEEDRUN & CHALLENGE MODES
# =========================================================

CHALLENGE_MODES = {
    "speedrun": {
        "name": "Speedrun",
        "description": "Reach level 10 as fast as possible",
        "timer": True,
        "leaderboard": True
    },
    "ironman": {
        "name": "Ironman",
        "description": "One death and you're out",
        "permadeath": True,
        "leaderboard": True
    },
    "budget_run": {
        "name": "Budget Run",
        "description": "Can't use any gold for purchases",
        "gold_locked": True,
        "leaderboard": True
    },
    "solo_challenge": {
        "name": "Solo Challenge",
        "description": "Fight bosses without companion help",
        "no_companions": True,
        "leaderboard": True
    }
}

# =========================================================
# STORY & LORE SYSTEM
# =========================================================

STORY_QUESTS = {
    "chapter_1": {
        "name": "The Beginning",
        "description": "Understand your purpose",
        "npcs": ["Elder of Woods"],
        "rewards": {"gold": 100, "title": "Novice"}
    },
    "chapter_2": {
        "name": "Elemental Crisis",
        "description": "Balance the elemental forces",
        "npcs": ["Ignar", "Glacien", "Voltis", "Sylvar"],
        "rewards": {"gold": 500, "title": "Adventurer"}
    },
    "chapter_3": {
        "name": "Void Rising",
        "description": "Stop the void from consuming the world",
        "npcs": ["Guardian of Light", "Source Oracle"],
        "rewards": {"gold": 1000, "title": "Champion"}
    }
}

# =========================================================
# EQUIPMENT ENCHANTING SYSTEM
# =========================================================

ENCHANTMENTS = {
    "strength": {"name": "Strength", "stat": "atk", "bonus": 3, "success_rate": 0.9},
    "resilience": {"name": "Resilience", "stat": "def", "bonus": 3, "success_rate": 0.9},
    "agility": {"name": "Agility", "stat": "spd", "bonus": 2, "success_rate": 0.85},
    "vitality": {"name": "Vitality", "stat": "hp", "bonus": 10, "success_rate": 0.95},
    "divine": {"name": "Divine", "stat": "all", "bonus": 5, "success_rate": 0.7},
    "shadow": {"name": "Shadow", "stat": "atk", "bonus": 6, "success_rate": 0.6}
}

# =========================================================
# NEW GAME+ MODE - PRESTIGE WITH SCALING
# =========================================================

NEWGAME_PLUS_CONFIG = {
    "difficulty_multiplier": 1.5,
    "enemy_scaling": 1.5,
    "reward_multiplier": 1.2,
    "material_multiplier": 1.3,
    "prestige_requirements": 3,
    "unlock_message": "New Game+ Mode Unlocked! Start a new run with 50% more rewards!"
}

# Bind defeated boss souls to weapons for special abilities and stat bonuses, souls accumulate power through combat
SOUL_BINDINGS = {
    "verdant_soul": {"boss": "The Verdant King", "bonus": {"atk": 5, "spd": 2}, "ability": "root_strike"},
    "infernal_soul": {"boss": "Lord of Infernos", "bonus": {"atk": 8, "def": 3}, "ability": "hellfire_burst"},
    "frost_soul": {"boss": "Frost Monarch", "bonus": {"def": 6, "spd": 1}, "ability": "absolute_zero"},
    "void_soul": {"boss": "Void Emperor", "bonus": {"atk": 10, "spd": 3}, "ability": "void_annihilation"}
}

# Battle Pass with seasonal tiers giving rewards for XP progression, premium track unlocks cosmetics
BATTLE_PASS_TIERS = {
    "tier_1": {"required_xp": 100, "rewards": {"gold": 50, "materials": {"crafting_shard": 1}}},
    "tier_5": {"required_xp": 500, "rewards": {"gold": 250, "cosmetic_currency": 50}},
    "tier_10": {"required_xp": 1000, "rewards": {"gold": 500, "cosmetic_currency": 150, "legendary_skin": True}},
    "tier_25": {"required_xp": 2500, "rewards": {"gold": 1500, "cosmetic_currency": 500, "exclusive_title": True}},
    "tier_50": {"required_xp": 5000, "rewards": {"gold": 3000, "cosmetic_currency": 1000, "prestige_token": 5}}
}

# Ritual Bonfire ceremonies grant temporary powerful buffs that scale with materials burned as offerings
RITUAL_CEREMONIES = {
    "blessing_of_strength": {"materials": {"metal_scraps": 5}, "duration_hours": 2, "bonus": {"atk": 3}},
    "shield_of_resilience": {"materials": {"cloth_scraps": 5}, "duration_hours": 2, "bonus": {"def": 3}},
    "swiftness_ritual": {"materials": {"essence_dust": 3}, "duration_hours": 2, "bonus": {"spd": 2}},
    "grand_ceremony": {"materials": {"rare_core": 1, "metal_scraps": 10}, "duration_hours": 4, "bonus": {"atk": 5, "def": 5, "spd": 3}}
}

# Battle other players in ranked arenas with seasonal leaderboards, collect trophy items from victories
ARENA_RANKS = ["Bronze", "Silver", "Gold", "Platinum", "Diamond", "Legendary"]
ARENA_REWARDS = {
    "win": {"gold": 50, "arena_points": 10},
    "loss": {"gold": 10, "arena_points": 1}
}

# Discover powerful crafting recipes through combat loot, each discovery increases chance of higher rarity drops
RECIPE_DISCOVERY = {
    "legendary_sword": {"materials": ["mithril_ore", "arcane_essence"], "discovery_rate": 0.05},
    "ethereal_armor": {"materials": ["celestial_cloth", "soul_thread"], "discovery_rate": 0.08},
    "enchanted_ring": {"materials": ["rare_core", "gem_dust"], "discovery_rate": 0.12}
}

# Create trading offers for other players with auto-expiry, collect prestige tokens from successful trades
TRADING_CONFIG = {
    "max_offers": 10,
    "offer_expiry_hours": 24,
    "tax_rate": 0.05
}

# Build and upgrade multiple town structures that generate passive resources, each structure unlocks new vendors
TOWN_STRUCTURES = {
    "tavern": {"name": "Tavern", "cost": 500, "bonus": "gold_generation"},
    "market": {"name": "Market", "cost": 750, "bonus": "trading_discounts"},
    "tower": {"name": "Tower", "cost": 1000, "bonus": "xp_boost"},
    "shrine": {"name": "Shrine", "cost": 600, "bonus": "blessing_buffs"}
}

# Daily login streaks grant escalating bonuses, reset at midnight, 30-day streaks unlock exclusive skins
LOGIN_BONUSES = {
    "day_1": {"gold": 50, "materials": {"crafting_shard": 1}},
    "day_3": {"gold": 150, "materials": {"essence_dust": 2}},
    "day_7": {"gold": 500, "cosmetic_currency": 100},
    "day_14": {"gold": 1000, "cosmetic_currency": 250},
    "day_30": {"gold": 2500, "cosmetic_currency": 500, "legendary_core": 1}
}

# Complete achievements for milestone rewards, earn badge cosmetics when completing achievement sets
ACHIEVEMENTS = {
    "first_victory": {"name": "First Victory", "description": "Defeat your first boss", "reward": 100},
    "monster_slayer": {"name": "Monster Slayer", "description": "Defeat 100 monsters", "reward": 200},
    "treasure_hunter": {"name": "Treasure Hunter", "description": "Find 50 legendary items", "reward": 300},
    "master_crafter": {"name": "Master Crafter", "description": "Craft 100 items", "reward": 250},
    "legendary_collector": {"name": "Legendary Collector", "description": "Own all legendary cosmetics", "reward": 500}
}

# Align with factions to gain permanent stat bonuses and unlock faction-exclusive vendors, can switch factions for cost
FACTIONS = {
    "crimson_order": {"name": "Crimson Order", "icon": "🔴", "bonuses": {"atk": 3, "crafting_speed": 0.1}},
    "frost_council": {"name": "Frost Council", "icon": "❄", "bonuses": {"def": 3, "material_find": 0.15}},
    "shadow_cult": {"name": "Shadow Cult", "icon": "🌑", "bonuses": {"spd": 3, "gold_gain": 0.2}},
    "light_clergy": {"name": "Light Clergy", "icon": "✨", "bonuses": {"hp": 10, "healing": 0.25}}
}

# Find treasure maps from defeated enemies that point to hidden loot stashes with randomized rewards, higher rarity maps have better treasure
TREASURE_MAPS = {
    "common": {"name": "Common Map", "find_chance": 0.4, "treasure_value": 100},
    "rare": {"name": "Rare Map", "find_chance": 0.2, "treasure_value": 500},
    "epic": {"name": "Epic Map", "find_chance": 0.08, "treasure_value": 2000},
    "legendary": {"name": "Legendary Map", "find_chance": 0.02, "treasure_value": 5000}
}

# Collect rideable mounts that provide travel speed bonuses and unlock mount cosmetics, each mount has special abilities
MOUNTS = {
    "wolf": {"name": "Dire Wolf", "speed_bonus": 1.3, "cost": 300},
    "dragon": {"name": "Drake", "speed_bonus": 1.8, "cost": 1500},
    "phoenix": {"name": "Phoenix", "speed_bonus": 2.0, "cost": 2000}
}

# Collect legendary artifacts throughout the world that grant unique stat bonuses, can equip multiple artifacts for synergy bonuses
ARTIFACTS = {
    "crown_of_kings": {"name": "Crown of Kings", "stats": {"atk": 5, "def": 5}, "rarity": "legendary"},
    "shield_of_ancients": {"name": "Shield of Ancients", "stats": {"def": 12}, "rarity": "epic"},
    "sword_of_justice": {"name": "Sword of Justice", "stats": {"atk": 15}, "rarity": "legendary"},
    "amulet_of_wisdom": {"name": "Amulet of Wisdom", "stats": {"mana": 30}, "rarity": "rare"}
}
